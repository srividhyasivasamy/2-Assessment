<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Criteria 3</name>
   <tag></tag>
   <elementGuidId>7404a91e-f4bb-4227-acc3-18cd84c8edb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 2'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(3) > button.big-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Criteria 3&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>9ecc7882-fbff-4f9e-9d24-0beeb792ce64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>big-button</value>
      <webElementGuid>bb886c6c-4969-4b7b-8037-19bd5a33b3ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Criteria 3</value>
      <webElementGuid>297d29e4-2427-4e98-a2c6-60570cce96b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-12&quot;]/div[@class=&quot;col-12 col-lg-12 col-xl-12&quot;]/a[3]/button[@class=&quot;big-button&quot;]</value>
      <webElementGuid>5f5a9370-db5d-4df1-8244-e6515b45aa47</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 2'])[1]/following::button[1]</value>
      <webElementGuid>857447d3-12db-4248-88b6-6566831f60b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 1'])[1]/following::button[2]</value>
      <webElementGuid>2f2658f5-a43b-466e-9688-d990476f3fbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 4'])[1]/preceding::button[1]</value>
      <webElementGuid>749a5422-cda1-41b6-87c2-a101cd479d60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 5'])[1]/preceding::button[2]</value>
      <webElementGuid>a17fbeda-40c8-443b-97db-ba223bd377ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Criteria 3']/parent::*</value>
      <webElementGuid>ff4a84a4-3b5f-4d50-9e0f-95545f04e1a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[3]/button</value>
      <webElementGuid>9f75099d-a118-4de8-ae8b-6e2fefe6bb0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Criteria 3' or . = 'Criteria 3')]</value>
      <webElementGuid>11640358-13b7-4bf4-9f91-391e76998345</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
