<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Criteria 4</name>
   <tag></tag>
   <elementGuidId>881ae56f-abc6-40e4-b080-de20d11c3a9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 3'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(4) > button.big-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Criteria 4&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>93408823-b802-4157-b857-bb22ac693508</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>big-button</value>
      <webElementGuid>de80e2bb-4ad9-4970-baa5-85f96a508bb4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Criteria 4</value>
      <webElementGuid>a6d7884c-ffd8-4726-bbc5-4aff3d4eb3a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-12&quot;]/div[@class=&quot;col-12 col-lg-12 col-xl-12&quot;]/a[4]/button[@class=&quot;big-button&quot;]</value>
      <webElementGuid>ffb22b08-0f7d-408f-aca8-6a7daa62c4e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 3'])[1]/following::button[1]</value>
      <webElementGuid>ed20060e-f79d-470f-bc68-3f31724daa54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 2'])[1]/following::button[2]</value>
      <webElementGuid>8f2d0065-0001-48ec-a474-9b9c2d9eab5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 5'])[1]/preceding::button[1]</value>
      <webElementGuid>f9e6cedc-6412-4ce0-b761-866167b2fb7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 6'])[1]/preceding::button[2]</value>
      <webElementGuid>22f6454d-5e5f-43d9-9227-0b05ae6477e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Criteria 4']/parent::*</value>
      <webElementGuid>2a3c4c4f-73b6-4a8e-8934-5a0d2d8d222f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[4]/button</value>
      <webElementGuid>768563a4-e0b8-46e0-a6a6-c538cba3559b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Criteria 4' or . = 'Criteria 4')]</value>
      <webElementGuid>dac80098-e3e8-4f36-bbfd-8f3ad366eea0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
