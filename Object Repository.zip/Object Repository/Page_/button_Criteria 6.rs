<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Criteria 6</name>
   <tag></tag>
   <elementGuidId>2be5c676-5739-45b7-9cef-2eace31b60e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 5'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(6) > button.big-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Criteria 6&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>760463ab-dd4d-4709-b96f-2ae2daade53c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>big-button</value>
      <webElementGuid>ad941721-1a68-47df-a935-0e1116e88442</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Criteria 6</value>
      <webElementGuid>111ad1d1-60a4-47eb-a9fe-2e3b2468e10c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-12&quot;]/div[@class=&quot;col-12 col-lg-12 col-xl-12&quot;]/a[6]/button[@class=&quot;big-button&quot;]</value>
      <webElementGuid>70823198-4705-45d6-bfd7-e0263f133924</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 5'])[1]/following::button[1]</value>
      <webElementGuid>7e182c33-d462-4ea5-967f-8c7a115d2d3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 4'])[1]/following::button[2]</value>
      <webElementGuid>06152f11-8a14-4ecd-9418-f50237c0ccde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 7'])[1]/preceding::button[1]</value>
      <webElementGuid>3391a022-908a-43e1-8658-e0cbb7ad4cc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 8'])[1]/preceding::button[2]</value>
      <webElementGuid>f529178b-8f8c-4acb-97b5-9ee497f10f56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Criteria 6']/parent::*</value>
      <webElementGuid>6a6f02db-9952-4cad-8177-39baa9c52451</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[6]/button</value>
      <webElementGuid>3b80cdc7-5dda-4186-a8ae-073a60c3ef44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Criteria 6' or . = 'Criteria 6')]</value>
      <webElementGuid>a629024f-5e53-453c-be3f-afb1de381b9c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
