<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Criteria 7</name>
   <tag></tag>
   <elementGuidId>1d41391e-01c3-48d7-ab42-4f688bdb4cb9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 6'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(7) > button.big-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Criteria 7&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>781721c1-867d-4492-9b5b-f9d6e2a3568a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>big-button</value>
      <webElementGuid>4729b398-a859-45e9-bcde-d5909846d503</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Criteria 7</value>
      <webElementGuid>49402fd8-ed4c-4023-9abf-9a54358ba50a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-12&quot;]/div[@class=&quot;col-12 col-lg-12 col-xl-12&quot;]/a[7]/button[@class=&quot;big-button&quot;]</value>
      <webElementGuid>80bd0d09-e93e-4853-ae4f-e3a1698c6c48</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 6'])[1]/following::button[1]</value>
      <webElementGuid>076930c1-6ebc-46ea-8877-2039edd55ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 5'])[1]/following::button[2]</value>
      <webElementGuid>3506996f-fb66-4f76-9bcd-b868c22b9fe1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 8'])[1]/preceding::button[1]</value>
      <webElementGuid>98d29ede-6416-4efa-bf34-da43204ef9b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='me'])[1]/preceding::button[2]</value>
      <webElementGuid>0a660f59-61da-4d41-bba2-fa5f3b55a144</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Criteria 7']/parent::*</value>
      <webElementGuid>9f10157a-97cc-453f-90de-8fc0170bd309</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[7]/button</value>
      <webElementGuid>13e84cff-21b9-41e2-98b6-dbb50c63fda7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Criteria 7' or . = 'Criteria 7')]</value>
      <webElementGuid>8b5ee63d-b7c6-4659-b2e8-a3e9808acaa4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
