<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Criteria 8</name>
   <tag></tag>
   <elementGuidId>60c18fe1-1112-4861-b41d-7b7b08eac38c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 7'])[1]/following::button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a:nth-of-type(8) > button.big-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Criteria 8&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>59bdd4ce-6722-4036-a5e3-87227a63e1cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>big-button</value>
      <webElementGuid>8dd3b960-baf6-404c-a1a3-e33dad4c4007</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Criteria 8</value>
      <webElementGuid>7d8e7af1-195b-4002-b793-7ae4506a2d7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-12&quot;]/div[@class=&quot;col-12 col-lg-12 col-xl-12&quot;]/a[8]/button[@class=&quot;big-button&quot;]</value>
      <webElementGuid>42ea9959-5a50-424c-a4f2-1d8f8803f76d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 7'])[1]/following::button[1]</value>
      <webElementGuid>4379705f-9303-4362-afe0-d8f98d7d69bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Criteria 6'])[1]/following::button[2]</value>
      <webElementGuid>63fb06fd-0410-4fe9-852b-10f8fea4de1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='me'])[1]/preceding::button[1]</value>
      <webElementGuid>05c4483f-cffa-4e8d-95fe-af94616badf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Criteria 8']/parent::*</value>
      <webElementGuid>bf0e1525-2cc9-4061-885a-ac657b90bed5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[8]/button</value>
      <webElementGuid>fb4596aa-db3d-4f38-9af5-f1dec8e7b11a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Criteria 8' or . = 'Criteria 8')]</value>
      <webElementGuid>c87cc21a-fdda-42b6-a5f4-be16d17750f1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
