<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_PG SYLLABUS-2018-2019</name>
   <tag></tag>
   <elementGuidId>fa8a0063-f5b9-4ce9-8131-878f912ac31f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;openPage('pg syll1819', this, '#D6F563')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;PG SYLLABUS-2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>16eac567-bf81-480b-8275-bf409462379a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tablink</value>
      <webElementGuid>e590cab6-3051-499d-b594-a9b1f55bc5ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>openPage('pg syll1819', this, '#D6F563')</value>
      <webElementGuid>80d0a402-c49d-4119-b6bd-fc7cf35a8867</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PG SYLLABUS-2018-2019</value>
      <webElementGuid>41fead5b-3af2-4235-aa39-90bb17ad98cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/strong[1]/div[@class=&quot;tab&quot;]/button[@class=&quot;tablink&quot;]</value>
      <webElementGuid>ba11a226-6145-43d7-ad4c-6ad7633e85b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;openPage('pg syll1819', this, '#D6F563')&quot;]</value>
      <webElementGuid>bbecb323-2ee0-4f2f-b05f-57a71bf87381</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SYLLABUS HOME'])[1]/following::button[1]</value>
      <webElementGuid>5ec0aca4-f4bd-41bb-994e-705aaeb979dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG SYLLABUS-2021-2022'])[1]/preceding::button[1]</value>
      <webElementGuid>c84a9ddb-6400-45ba-88c9-dbd6ac60147c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MAJOR PAPERS'])[1]/preceding::button[2]</value>
      <webElementGuid>13dd70e1-5bf5-4930-8e53-9066994f0faf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PG SYLLABUS-2018-2019']/parent::*</value>
      <webElementGuid>ccb55f22-f953-4dc6-91d5-36ade79ff966</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]</value>
      <webElementGuid>290a590c-634c-498f-8a86-77c55181e311</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'PG SYLLABUS-2018-2019' or . = 'PG SYLLABUS-2018-2019')]</value>
      <webElementGuid>fc28a57a-2c80-4c49-b338-1b29bb744a08</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
