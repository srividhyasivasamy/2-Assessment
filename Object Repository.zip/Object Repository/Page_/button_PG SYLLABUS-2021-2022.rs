<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_PG SYLLABUS-2021-2022</name>
   <tag></tag>
   <elementGuidId>a3890285-c140-4c74-8979-96f1dca19d66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;openPage('pg syll2122', this, '#D6F563')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;PG SYLLABUS-2021-2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>7c75b49a-4781-42a4-80cd-f2b91166bf19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tablink</value>
      <webElementGuid>65b5a169-8eac-466a-acd0-e66e62badf62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>openPage('pg syll2122', this, '#D6F563')</value>
      <webElementGuid>3143c805-373f-47c8-9204-76b093dee761</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PG SYLLABUS-2021-2022</value>
      <webElementGuid>4c479a21-17e6-40be-a9a8-75e3dc0b1cb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/strong[1]/div[@class=&quot;tab&quot;]/button[@class=&quot;tablink&quot;]</value>
      <webElementGuid>72af70b7-1ffd-47af-980a-2fde5157cdcf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;openPage('pg syll2122', this, '#D6F563')&quot;]</value>
      <webElementGuid>d9263618-00a6-4cd1-a01e-3d018f4054c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG SYLLABUS-2018-2019'])[1]/following::button[1]</value>
      <webElementGuid>0b2c6eaf-dcd6-474c-9c50-6684a36833aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SYLLABUS HOME'])[1]/following::button[2]</value>
      <webElementGuid>0ef578f5-67a7-4bc6-b81a-ab6d8ba710ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MAJOR PAPERS'])[1]/preceding::button[1]</value>
      <webElementGuid>6ad94da8-919b-4d7d-bec4-4d3828239971</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M.Sc BOTANY'])[1]/preceding::button[1]</value>
      <webElementGuid>0be9fc84-dc7b-4e3b-9e8f-d65e8d16ae7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PG SYLLABUS-2021-2022']/parent::*</value>
      <webElementGuid>3910c12a-2342-40b5-b22b-19f46185c215</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[3]</value>
      <webElementGuid>0cb8d63e-6bfd-48bc-8818-fb7b0e67f50b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'PG SYLLABUS-2021-2022' or . = 'PG SYLLABUS-2021-2022')]</value>
      <webElementGuid>cf23d4ad-3cdb-4049-a895-c6f83782b0f5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
