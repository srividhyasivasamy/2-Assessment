<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Revised TANSCHE Syllabus-2023(Click _27bf96</name>
   <tag></tag>
   <elementGuidId>4b7ff826-b613-4b4b-9e1e-452c8bd0b629</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;openCity(event, 'po pso')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.tablinks</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Revised TANSCHE Syllabus-2023(Click here to view all the syllabus)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>dd8c4d86-91cc-47d9-be60-ee2e1f995166</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tablinks</value>
      <webElementGuid>6624966b-4cd3-4c19-b7cf-f9a82bb25501</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>openCity(event, 'po pso')</value>
      <webElementGuid>cc2077ef-9e8b-4c0e-902d-95b280adc904</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Revised TANSCHE Syllabus-2023(Click here to view all the syllabus) </value>
      <webElementGuid>5f063f58-e564-46a3-8803-49adfad2c195</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/center[1]/h3[1]/strong[1]/div[@class=&quot;tab&quot;]/button[@class=&quot;tablinks&quot;]</value>
      <webElementGuid>6f20d9d0-650c-4cf1-86ab-42e5035dd161</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;openCity(event, 'po pso')&quot;]</value>
      <webElementGuid>b31b5e5a-9418-439e-8730-d8d2c3ce89dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S.No'])[1]/preceding::button[1]</value>
      <webElementGuid>1bfb3a88-d070-4a6c-a04b-53c36d25f159</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG-Arts'])[1]/preceding::button[1]</value>
      <webElementGuid>d9d1f593-8e8f-4727-b4fa-ce4446add603</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Revised TANSCHE Syllabus-2023(Click here to view all the syllabus)']/parent::*</value>
      <webElementGuid>390fd273-15d3-4d5a-b60b-c7eef72650aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>b5e4d23c-1ae6-4733-bddc-77d75ae5dcdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Revised TANSCHE Syllabus-2023(Click here to view all the syllabus) ' or . = 'Revised TANSCHE Syllabus-2023(Click here to view all the syllabus) ')]</value>
      <webElementGuid>7540c595-7e12-4560-abc3-2461b5aeb62c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
