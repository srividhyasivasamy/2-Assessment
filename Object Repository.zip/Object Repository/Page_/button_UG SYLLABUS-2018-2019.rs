<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_UG SYLLABUS-2018-2019</name>
   <tag></tag>
   <elementGuidId>2fdc5596-560b-4e76-930b-65a90f369540</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;openPage('syll1819', this, '#D6F563')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;UG SYLLABUS-2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ac6110f8-6e97-45d9-8c6c-b5d6135f8cc2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tablink</value>
      <webElementGuid>64c8c054-75ba-41e0-b5e2-c14ad861b59d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>openPage('syll1819', this, '#D6F563')</value>
      <webElementGuid>461550e4-8842-4873-b9cf-56b20edd9063</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG SYLLABUS-2018-2019</value>
      <webElementGuid>3576679a-6d12-4c70-9551-a407454399ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/strong[1]/div[@class=&quot;tab&quot;]/button[@class=&quot;tablink&quot;]</value>
      <webElementGuid>291a42c5-6b5f-4afe-b187-8099fd22d38f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;openPage('syll1819', this, '#D6F563')&quot;]</value>
      <webElementGuid>38789a38-e0b8-4c41-863a-09ce25f6116c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SYLLABUS HOME'])[1]/following::button[1]</value>
      <webElementGuid>1610c215-e8de-48f8-bf1d-25f9aaa23302</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG SYLLABUS-2021-2022'])[1]/preceding::button[1]</value>
      <webElementGuid>c028c65d-bf8b-44b3-9e93-e7f29e1e49b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PART I'])[1]/preceding::button[2]</value>
      <webElementGuid>bf9f6d6a-6f24-4b1e-9ada-2bfd88f3d960</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG SYLLABUS-2018-2019']/parent::*</value>
      <webElementGuid>8f13f3c5-1cb1-4e28-a758-accef95038a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]</value>
      <webElementGuid>c54af686-e3cf-4fcb-9faa-9767e300c4a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'UG SYLLABUS-2018-2019' or . = 'UG SYLLABUS-2018-2019')]</value>
      <webElementGuid>a1f0e1f5-ddd5-44df-aac5-324c873b2901</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
