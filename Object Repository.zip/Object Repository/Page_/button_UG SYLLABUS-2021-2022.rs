<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_UG SYLLABUS-2021-2022</name>
   <tag></tag>
   <elementGuidId>7e04c7a5-3d3e-42d9-8cff-6e068fc68e54</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@onclick=&quot;openPage('syll2122', this, '#D6F563')&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;UG SYLLABUS-2021-2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>997b4ee4-4315-4a20-b518-73a07697aa55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tablink</value>
      <webElementGuid>75f5f007-0699-45a3-9118-221fe972a72f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>openPage('syll2122', this, '#D6F563')</value>
      <webElementGuid>5e8850eb-4490-4616-8281-47a28d3bd882</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG SYLLABUS-2021-2022</value>
      <webElementGuid>15988768-35a9-44f2-b245-998e6de171cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/strong[1]/div[@class=&quot;tab&quot;]/button[@class=&quot;tablink&quot;]</value>
      <webElementGuid>6678a9ef-32f6-4dcc-b64c-6732a06b4d1f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@onclick=&quot;openPage('syll2122', this, '#D6F563')&quot;]</value>
      <webElementGuid>98ffa8de-f2d7-4e9b-848f-2921bfd9b950</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG SYLLABUS-2018-2019'])[1]/following::button[1]</value>
      <webElementGuid>f6f476eb-7bb2-483e-a6dc-0e162dd31ac4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SYLLABUS HOME'])[1]/following::button[2]</value>
      <webElementGuid>b930a2ca-71e9-42bf-865d-0742f4088275</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PART I'])[1]/preceding::button[1]</value>
      <webElementGuid>1404359b-884a-4db7-9584-dcacbf7113fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TAMIL'])[1]/preceding::button[1]</value>
      <webElementGuid>1278343b-d15c-4249-af7f-fdf6d5a1d8d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG SYLLABUS-2021-2022']/parent::*</value>
      <webElementGuid>7abd08c0-f821-452f-aef1-71ae412b7109</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[3]</value>
      <webElementGuid>21772d8b-e863-41a5-8503-218f6e737e4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'UG SYLLABUS-2021-2022' or . = 'UG SYLLABUS-2021-2022')]</value>
      <webElementGuid>bff48a05-64c2-463b-b91c-b9f9e5049d74</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
