<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_BCA_fa fa-file-pdf-o</name>
   <tag></tag>
   <elementGuidId>fd124d6d-677b-434b-b40e-f9ece41b8206</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='customers']/tbody/tr[15]/td[2]/a/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(15) > td:nth-of-type(2) > a > i.fa.fa-file-pdf-o</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;BCA &quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>01f36bc0-09c3-4e4f-b4e1-f224981c4116</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-file-pdf-o</value>
      <webElementGuid>246775b5-3551-46db-a4e9-a41947fda914</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/center[1]/div[@id=&quot;syll1819&quot;]/form[@id=&quot;syll1819&quot;]/div[1]/center[1]/strong[1]/h5[1]/table[@id=&quot;customers&quot;]/tbody[1]/tr[15]/td[2]/a[1]/i[@class=&quot;fa fa-file-pdf-o&quot;]</value>
      <webElementGuid>a51c1ee8-0444-451d-9b82-0874b1e2d854</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='customers']/tbody/tr[15]/td[2]/a/i</value>
      <webElementGuid>b32337f1-302f-498d-b522-f44c27bc00e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[15]/td[2]/a/i</value>
      <webElementGuid>0d0484a8-249e-4d0f-a3aa-f80f1e0e1075</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
