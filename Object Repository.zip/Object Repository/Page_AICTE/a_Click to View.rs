<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click to View</name>
   <tag></tag>
   <elementGuidId>39ac2fa4-07a5-4ede-9ceb-5a07dc4daa76</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li/span/strong/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Click to View&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>strong >> internal:has-text=&quot;Mandatory Disclosure - Click to View&quot;i >> internal:attr=[title=&quot;Click to View&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f7d88dab-8980-488c-9f20-4fff04cc75c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/Mandatory-Disclosure-2023-24.pdf</value>
      <webElementGuid>c2e0cfde-eb75-47a5-a400-be9c4b9d14d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Click to View</value>
      <webElementGuid>79eaaccf-0d6b-4d00-93e8-d6b21e486b26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click to View</value>
      <webElementGuid>769035c7-de50-44d7-853c-b6eb40968557</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/ul[1]/li[1]/span[1]/strong[1]/a[1]</value>
      <webElementGuid>09933475-758d-4037-841a-c33c8a122d12</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li/span/strong/a</value>
      <webElementGuid>89bbb843-5d57-43ba-945d-9e3a2f99351c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Click to View')]</value>
      <webElementGuid>2e8e506d-7109-43cc-8445-dab989df531e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MCA'])[1]/preceding::a[1]</value>
      <webElementGuid>08eadbd2-8452-4e4a-840a-cc72be3650ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click to View']/parent::*</value>
      <webElementGuid>a2c73c9d-9778-429b-ba79-2e696622565b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/Mandatory-Disclosure-2023-24.pdf')]</value>
      <webElementGuid>e1316afb-23ba-457e-a4d9-ca6b2753d32b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//strong/a</value>
      <webElementGuid>51373b52-0221-4e37-ad2b-36da4f0931ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/Mandatory-Disclosure-2023-24.pdf' and @title = 'Click to View' and (text() = 'Click to View' or . = 'Click to View')]</value>
      <webElementGuid>9e772733-130c-4665-b823-2ffcc53740a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
