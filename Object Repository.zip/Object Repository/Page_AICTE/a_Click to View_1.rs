<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click to View_1</name>
   <tag></tag>
   <elementGuidId>6d1dada9-b1c1-4e44-aced-02ee0bb3473c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li[2]/ul/li/ul/li/span/strong/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li > ul > li > span > strong > a[title=&quot;Click to View&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li > ul > li > span > strong > a >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ec673152-9eb6-4f08-bd03-0a7ce4891832</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/EOAReport21-22-MCA.PDF</value>
      <webElementGuid>f190a8af-ffec-4782-855f-0b3a5e56699e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Click to View</value>
      <webElementGuid>4f8f1908-156a-4e23-a182-93cb542c1e95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click to View</value>
      <webElementGuid>c266169f-1951-46fe-8db9-b5a6dcd24477</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/ul[1]/li[2]/ul[1]/li[1]/ul[1]/li[1]/span[1]/strong[1]/a[1]</value>
      <webElementGuid>819a91eb-902d-4f3f-8bea-431e4d950561</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li[2]/ul/li/ul/li/span/strong/a</value>
      <webElementGuid>38577a41-d224-46a5-a831-e10d9c09c8a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click to View')])[2]</value>
      <webElementGuid>c8fb10d4-776b-4401-aab9-be362cc3277c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MCA'])[1]/following::a[1]</value>
      <webElementGuid>13d88d9f-3e82-4f7b-ab4f-0a6c89211751</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click to View'])[3]/preceding::a[1]</value>
      <webElementGuid>14b3078b-82c3-4bee-9bd6-26255604d1f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click to View'])[4]/preceding::a[2]</value>
      <webElementGuid>fbeb8869-8b48-4fcb-a4b9-2f7374c11942</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/EOAReport21-22-MCA.PDF')]</value>
      <webElementGuid>a4109385-da68-4a0b-a45d-410577d5bd7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/ul/li/span/strong/a</value>
      <webElementGuid>12d13038-79ef-46e0-bf1f-45f6f56737c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/About Us/EOAReport21-22-MCA.PDF' and @title = 'Click to View' and (text() = 'Click to View' or . = 'Click to View')]</value>
      <webElementGuid>def68d0c-62f2-4c3f-8cdc-79df50ffb28f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
