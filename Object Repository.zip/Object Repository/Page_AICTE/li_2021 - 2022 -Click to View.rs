<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_2021 - 2022 -Click to View</name>
   <tag></tag>
   <elementGuidId>cd5d8b6a-fee3-4890-9c0e-873ce8e50ad3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li[2]/ul/li/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div > ul > li:nth-of-type(2) > ul > li > ul > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;2021 - 2022 - Click to View&quot;i >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>c294678c-35d5-4035-ba5a-2941f9f087f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>2021 - 2022 - Click to View</value>
      <webElementGuid>6355c9ac-d185-46d5-ad1a-977ff777db89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/ul[1]/li[2]/ul[1]/li[1]/ul[1]/li[1]</value>
      <webElementGuid>4e95a065-afbf-4ed3-b6fc-86aa6988dbdc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/ul/li[2]/ul/li/ul/li</value>
      <webElementGuid>709fd38d-1e46-4033-8915-ae26daaac166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MCA'])[1]/following::li[1]</value>
      <webElementGuid>c21ad9da-8ca2-4fea-a491-b30258fe2ded</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click to View'])[3]/preceding::li[1]</value>
      <webElementGuid>23dfadaf-a529-4f6b-93d2-1671fbde5101</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[2]/ul/li/ul/li</value>
      <webElementGuid>9bc0a780-b794-4414-ab79-b3d3362f24e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '2021 - 2022 - Click to View' or . = '2021 - 2022 - Click to View')]</value>
      <webElementGuid>1c5826f8-e005-47dc-8a58-a4342eb2fb6f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
