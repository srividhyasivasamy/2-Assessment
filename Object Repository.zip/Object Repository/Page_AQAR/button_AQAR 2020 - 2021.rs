<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_AQAR 2020 - 2021</name>
   <tag></tag>
   <elementGuidId>321f292b-d330-49da-9eed-481c6a2ceedb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[4]/a/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;AQAR 2020 - 2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>35b34494-e741-4b04-a608-dddaaca72667</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button-arounder</value>
      <webElementGuid>99d891ae-410e-48f2-89b5-0a79f0184c53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AQAR 2020 - 2021
 </value>
      <webElementGuid>abb24e0c-d305-46b0-a17a-91fe27af727e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/div[@class=&quot;buttons-container&quot;]/a[1]/button[@class=&quot;button-arounder&quot;]</value>
      <webElementGuid>f8aea055-f2d7-4525-9493-56d51238edbc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[4]/a/button</value>
      <webElementGuid>0d4b4de4-1538-41c4-bca4-a28572748712</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2021 - 2022'])[1]/following::button[1]</value>
      <webElementGuid>29639374-c197-4511-bbac-9b2a80cb76c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2022 - 2023'])[1]/following::button[2]</value>
      <webElementGuid>d27324c2-4b38-4836-8bb3-037ca873c87a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2019 - 2020'])[1]/preceding::button[1]</value>
      <webElementGuid>ea319479-5047-4e8c-a103-8544b19df62c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2018 - 2019'])[1]/preceding::button[2]</value>
      <webElementGuid>ba7222c7-de1a-4ffc-806c-4e8fb0bfc5de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AQAR 2020 - 2021']/parent::*</value>
      <webElementGuid>ac63be4e-47fb-47d5-bf52-cfc1ebd145b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a/button</value>
      <webElementGuid>7dc3f3d0-b223-4163-9b4a-9b3244b8639f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'AQAR 2020 - 2021
 ' or . = 'AQAR 2020 - 2021
 ')]</value>
      <webElementGuid>2cb78b76-d5db-4513-9e54-3b31da458d03</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
