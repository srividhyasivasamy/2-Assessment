<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_AQAR 2021 - 2022</name>
   <tag></tag>
   <elementGuidId>017d088f-50f1-47dc-ab2a-8ac88aa5a485</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[3]/a/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;AQAR 2021 - 2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ddeaf545-2dc2-4d35-9dbc-13221745685c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button-arounder</value>
      <webElementGuid>d66afd0b-ecb1-45d8-96b7-790bdd7e8212</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AQAR 2021 - 2022
 </value>
      <webElementGuid>96832d16-ac33-4b0a-b5cb-70adb4371927</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/div[@class=&quot;buttons-container&quot;]/a[1]/button[@class=&quot;button-arounder&quot;]</value>
      <webElementGuid>6b2dcf7d-3e03-4ef9-8ad8-6fd0701ed49c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[3]/a/button</value>
      <webElementGuid>856d367a-e12f-43b4-80c6-7a4ebbd232e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2022 - 2023'])[1]/following::button[1]</value>
      <webElementGuid>f71c852a-b0e9-4102-a0b7-0ff309c1dd59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2020 - 2021'])[1]/preceding::button[1]</value>
      <webElementGuid>ff6b81d1-74e3-4cc6-8fe0-00292789b8ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2019 - 2020'])[1]/preceding::button[2]</value>
      <webElementGuid>4e612154-33b7-4adc-b6fe-e5bbc701e816</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AQAR 2021 - 2022']/parent::*</value>
      <webElementGuid>d5e3b176-a2d9-4642-a8d4-a704f42a9457</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/button</value>
      <webElementGuid>f71fd0c0-0172-43b7-bae1-9f175df301b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'AQAR 2021 - 2022
 ' or . = 'AQAR 2021 - 2022
 ')]</value>
      <webElementGuid>b780f211-5f25-4a9b-86d0-bb0a7f3a33a7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
