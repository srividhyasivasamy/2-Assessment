<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_AQAR 2022 - 2023</name>
   <tag></tag>
   <elementGuidId>f7e7b1c1-1c3b-4229-bc30-377345157b46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[2]/a/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.button-arounder</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;AQAR 2022 - 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>52dbfac2-faa8-4687-a037-7775e589e799</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button-arounder</value>
      <webElementGuid>9d5b9d12-8d9e-4160-b97c-1d3040818787</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AQAR 2022 - 2023
 </value>
      <webElementGuid>6e6f7d78-0547-4772-9d9f-569b54d0ed32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/div[@class=&quot;buttons-container&quot;]/a[1]/button[@class=&quot;button-arounder&quot;]</value>
      <webElementGuid>479bad72-a06e-4cc8-987d-9cfb2a1676a9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[2]/a/button</value>
      <webElementGuid>f7cd69d8-a1a9-499c-95e3-d5abe8804f9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR'])[3]/following::button[1]</value>
      <webElementGuid>c26ba50d-0b73-4b59-b574-762ceb62ab0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2021 - 2022'])[1]/preceding::button[1]</value>
      <webElementGuid>a2d2f824-a63f-48b6-a846-b31e59cf7015</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2020 - 2021'])[1]/preceding::button[2]</value>
      <webElementGuid>9067d779-2032-4ac9-883c-420868185a86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AQAR 2022 - 2023']/parent::*</value>
      <webElementGuid>3c2bc86f-5a46-4464-8edf-f254c25c1dbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>89386531-a7ed-48e8-b90a-fd7757ba2d78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'AQAR 2022 - 2023
 ' or . = 'AQAR 2022 - 2023
 ')]</value>
      <webElementGuid>49684c7e-0389-4a73-b302-61935dad0c56</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
