<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Strategic Plan  Deployment</name>
   <tag></tag>
   <elementGuidId>242e1bae-ea40-463c-a7ef-d3133f119280</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[10]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Strategic Plan &amp; Deployment&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d59713bc-90c8-4a96-b763-b589b1adc2de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/strategic-plan-and-deployment</value>
      <webElementGuid>45608c62-73b5-4e9e-9812-68c0ab824023</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Strategic Plan &amp; Deployment</value>
      <webElementGuid>295e26e8-cba7-43d1-9e06-9eee5e7a57c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[10]/a[1]</value>
      <webElementGuid>603812e1-6949-46c1-b30f-b149632e8930</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[10]/a</value>
      <webElementGuid>d3ee0848-11b2-4b8b-8186-b84f3c5a5e89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Strategic Plan &amp; Deployment')]</value>
      <webElementGuid>1a48288a-416b-4920-9f06-f2e8e61592e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Audit'])[2]/following::a[1]</value>
      <webElementGuid>68b5f29b-66f7-448d-b728-c9c6c0fead8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quality Initiatives'])[1]/following::a[2]</value>
      <webElementGuid>63671a77-1053-44c7-b800-c53849e4fe71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/preceding::a[1]</value>
      <webElementGuid>1a0dd1ac-796e-4251-953f-f910f84f467b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[1]/preceding::a[2]</value>
      <webElementGuid>9db38c78-c04c-4057-b617-266b89c2c0e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Strategic Plan &amp; Deployment']/parent::*</value>
      <webElementGuid>38cab12c-5da5-4581-aaa1-b4526acd8eb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/strategic-plan-and-deployment')]</value>
      <webElementGuid>f6215f8c-2b36-40f0-98d2-ddb809780002</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/ul/li[10]/a</value>
      <webElementGuid>3eabfa98-9ddf-44d0-95ef-7b4f9fd755b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/strategic-plan-and-deployment' and (text() = 'Strategic Plan &amp; Deployment' or . = 'Strategic Plan &amp; Deployment')]</value>
      <webElementGuid>c66ee732-1f42-4df8-9496-bb9c72454e40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
