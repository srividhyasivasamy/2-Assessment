<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Calendar - 2020-2021</name>
   <tag></tag>
   <elementGuidId>c4343ba5-7c64-4165-beb7-711c0d4e4772</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Academic Calendar - 2020-2021&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Calendar - 2020-2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>db986ca7-58fa-4994-9f3a-b43e177ce4fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2020-2021.pdf</value>
      <webElementGuid>8f0cb317-c538-490f-b10b-3ebb3cc622ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Academic Calendar - 2020-2021</value>
      <webElementGuid>a17f9f9a-64b7-49d3-8336-99791de1ec96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>b977f4ee-b90f-4f39-a5ce-43cfdfcb5622</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Calendar - 2020-2021</value>
      <webElementGuid>8671b7b0-0625-497e-ab45-f57883e3c9c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[4]/a[1]</value>
      <webElementGuid>0eded5c6-3aed-4bca-98ca-bdd258628313</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      <webElementGuid>2b198b11-6c5b-42d0-87e9-eb2007fef81e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Calendar - 2020-2021')]</value>
      <webElementGuid>af37df28-d6df-45ce-8fb9-d69eacd269f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2021-2022'])[1]/following::a[1]</value>
      <webElementGuid>63241e3d-429d-4580-8989-40a043f9361b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2022-2023'])[1]/following::a[2]</value>
      <webElementGuid>f299bd80-3bdf-4bfe-909c-0e786ae90b7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2019-2020'])[1]/preceding::a[1]</value>
      <webElementGuid>25c9bdfb-4ce6-4395-9128-d3e82670b7e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2018-2019'])[1]/preceding::a[2]</value>
      <webElementGuid>823fa740-8407-497f-accb-3c190e0c4b60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Calendar - 2020-2021']/parent::*</value>
      <webElementGuid>f5df0812-de25-40d6-b7f6-6fe68f60c7be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2020-2021.pdf')]</value>
      <webElementGuid>e13f2240-44ed-41d8-bb50-d20a654cce3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/a</value>
      <webElementGuid>00d14593-23eb-4a31-9b30-9232ed430ef7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2020-2021.pdf' and @title = 'Academic Calendar - 2020-2021' and (text() = 'Academic Calendar - 2020-2021' or . = 'Academic Calendar - 2020-2021')]</value>
      <webElementGuid>0e9cf18f-dedf-4770-848e-6660c2ddcad2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
