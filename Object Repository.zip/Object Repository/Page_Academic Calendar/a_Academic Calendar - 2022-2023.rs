<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Calendar - 2022-2023</name>
   <tag></tag>
   <elementGuidId>c44797cb-2adf-4942-99ed-8d6564236a67</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Academic Calendar - 2022-2023&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Calendar - 2022-2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fc46c5eb-e9c2-46de-aa65-b791193cf41c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf</value>
      <webElementGuid>94a28f23-863e-442f-98d0-f379f5786df5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Academic Calendar - 2022-2023</value>
      <webElementGuid>a8833d54-1ed0-40a8-9aeb-a7b91f6469f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>f41d8c51-1216-4649-befc-b65cfe164a1b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Calendar - 2022-2023</value>
      <webElementGuid>8578447b-f776-425f-8b09-763efc2158b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[2]/a[1]</value>
      <webElementGuid>c506a4a7-28f5-4f19-9033-5a55fe312af8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      <webElementGuid>f1f0dcba-1c76-420e-96bc-ec961a90d762</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Calendar - 2022-2023')]</value>
      <webElementGuid>0054203c-1360-4167-a5f1-4aadc6b337d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2023-2024'])[1]/following::a[1]</value>
      <webElementGuid>9e7c7d14-409a-4d41-9e57-30605913347a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ACADEMIC CALENDAR'])[1]/following::a[2]</value>
      <webElementGuid>d2c678c7-842f-4644-976d-5f81c3c55280</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2021-2022'])[1]/preceding::a[1]</value>
      <webElementGuid>a41a5a02-120e-4abc-95c2-487b8a17d0c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2020-2021'])[1]/preceding::a[2]</value>
      <webElementGuid>04cdddf6-5ff6-41c2-a53e-bbb145799ff0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Calendar - 2022-2023']/parent::*</value>
      <webElementGuid>ce898ff9-2581-4f0d-8b57-a6554e6b09a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf')]</value>
      <webElementGuid>623de06e-b53f-420f-9338-114a0d4e3777</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/a</value>
      <webElementGuid>469a3c7f-7b11-46db-9528-2bb0c4174c3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf' and @title = 'Academic Calendar - 2022-2023' and (text() = 'Academic Calendar - 2022-2023' or . = 'Academic Calendar - 2022-2023')]</value>
      <webElementGuid>49092f75-a740-4f98-86ab-d5169da61c40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
