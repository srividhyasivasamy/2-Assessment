<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Women Harassment, Grievance Redressal  Ombudsman</name>
   <tag></tag>
   <elementGuidId>c9434905-5d95-422c-9a1e-4dff90b34cc3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Women Harassment, Grievance Redressal &amp; Ombudsman&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c73c194e-1293-483a-b0fd-f705020f39f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/women-harassment-grievance-redressal--ombudsman</value>
      <webElementGuid>c7fcf982-4cb2-41ff-a274-7e200342a718</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Women Harassment, Grievance Redressal &amp; Ombudsman</value>
      <webElementGuid>f4cc807e-46c3-4735-b0a2-13cd4f64cdfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[4]/a[1]</value>
      <webElementGuid>afa59f4f-cfc0-4504-aa56-0e53f3027e07</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[4]/a</value>
      <webElementGuid>6e23cd34-2457-4aa4-814e-ca123630abfc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Women Harassment, Grievance Redressal &amp; Ombudsman')]</value>
      <webElementGuid>4cda7d17-8ce1-46d9-bed8-a8c8c5ca9671</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Welfare Committee'])[1]/following::a[1]</value>
      <webElementGuid>e830c815-cf2e-4914-9e06-5768cb3eb583</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Anti-ragging Committee'])[1]/following::a[2]</value>
      <webElementGuid>9e7b6623-432e-4fbb-bfd6-763ddbcbfa1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Committee for Disability Students'])[1]/preceding::a[1]</value>
      <webElementGuid>3ca429c7-0a15-4d4a-ad5e-bffff39325cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDC cum Earn while you Learn'])[1]/preceding::a[2]</value>
      <webElementGuid>bb5e15b4-4380-45ce-be69-d546c1b7ab29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Women Harassment, Grievance Redressal &amp; Ombudsman']/parent::*</value>
      <webElementGuid>e1a1213d-07b9-473e-80d0-9b8f9345974a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/women-harassment-grievance-redressal--ombudsman')]</value>
      <webElementGuid>16c27d0a-9d61-4e7f-98cf-343c3ff49505</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li[2]/ul/li[4]/a</value>
      <webElementGuid>529a1532-532a-43ff-8d1f-ccd834ec9577</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/women-harassment-grievance-redressal--ombudsman' and (text() = 'Women Harassment, Grievance Redressal &amp; Ombudsman' or . = 'Women Harassment, Grievance Redressal &amp; Ombudsman')]</value>
      <webElementGuid>3eba544b-4376-4bfb-99dc-3672d921d985</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
