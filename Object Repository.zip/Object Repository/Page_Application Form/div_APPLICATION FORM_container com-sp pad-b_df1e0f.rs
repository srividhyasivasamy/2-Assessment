<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_APPLICATION FORM_container com-sp pad-b_df1e0f</name>
   <tag></tag>
   <elementGuidId>fcb98820-2427-4a19-a640-0901e5ef3b64</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.container.com-sp.pad-bot-70.pg-inn.ps_min_height.px-5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>section:nth-child(2) > .container</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5c7bdecb-2bea-4a53-b9db-b7ce2db9a7f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container com-sp pad-bot-70 pg-inn ps_min_height px-5</value>
      <webElementGuid>442545ce-0e75-4be0-92cb-db6cf5a2e2f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]</value>
      <webElementGuid>166d392c-f0ca-4277-84c9-60a9cee19326</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div</value>
      <webElementGuid>df7cca7c-a4a7-4677-a750-2693cc7c6cca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLICATION FORM'])[1]/following::div[1]</value>
      <webElementGuid>17ce8262-1d23-4ace-bf7b-441f815287ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[10]</value>
      <webElementGuid>727cf9e0-4595-41ed-9047-ff241f0a3156</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::div[4]</value>
      <webElementGuid>7517fca0-62d4-4591-99fb-3e5ee58d19db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::div[5]</value>
      <webElementGuid>0b35a4a5-6b87-48f6-b3e3-6ef53b377f4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/section[2]/div</value>
      <webElementGuid>fc71cf76-3096-4d60-8761-b31d70053d32</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
