<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Finance Committee</name>
   <tag></tag>
   <elementGuidId>31fbe9cd-8376-496e-93ac-6c6a695a4f97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Finance Committee&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d34ffdf0-a643-44b6-ac5a-9815f3a99665</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/finance-committee</value>
      <webElementGuid>9eef397d-2f01-4d88-8711-05b2d69431fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Finance Committee</value>
      <webElementGuid>436ee945-88d5-43fc-ad9e-2e5225abdf4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[5]/a[1]</value>
      <webElementGuid>6bf8ccf0-faee-48be-a8ff-4e5c765ef4dc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li/ul/li[5]/a</value>
      <webElementGuid>04354108-ae85-46bd-a612-f470a74bb66f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Finance Committee')]</value>
      <webElementGuid>6951cbc6-2b42-47c8-b282-a35d7f566c19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BoS'])[2]/following::a[1]</value>
      <webElementGuid>047bac67-fcf1-4d67-8a49-d53907ff027b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Curriculum Development Cell'])[1]/following::a[2]</value>
      <webElementGuid>4090b967-4b5b-484b-af6a-2fc887345c8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Awards Committee'])[1]/preceding::a[1]</value>
      <webElementGuid>1ddb34c2-0d01-457a-ac54-1ef4facfe07e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Non-Statutory Bodies'])[1]/preceding::a[2]</value>
      <webElementGuid>7ad7f820-251c-4651-a3c8-079fc7664cf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Finance Committee']/parent::*</value>
      <webElementGuid>544101c4-c4c3-442b-a5d3-089b924ae914</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/finance-committee')]</value>
      <webElementGuid>786e78e6-4fe4-4f11-9ae1-9afe693fe802</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li/ul/li[5]/a</value>
      <webElementGuid>a42343c3-bcfa-4222-9f49-96742bec0d93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/finance-committee' and (text() = 'Finance Committee' or . = 'Finance Committee')]</value>
      <webElementGuid>7c469460-cd09-4f98-bfc6-ded4ec8e8bb0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
