<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_COMPUTER SCIENCE</name>
   <tag></tag>
   <elementGuidId>ac4a61aa-a393-4f75-bdf5-62e9af32bc3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[13]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(13) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;COMPUTER SCIENCE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>25a8b48c-9d4a-4c16-ae94-6a5d7f3debc6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>2df29265-f748-4a3e-b2a8-564576e78711</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/14/computer-science</value>
      <webElementGuid>d5de6e04-66fc-47cf-9686-bc85c8ff5ffb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>COMPUTER SCIENCE</value>
      <webElementGuid>e4a60542-2b09-4ce3-8dc5-911f70b7552f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[13]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>4ef797ae-2696-4087-bcb5-d7aa03c21161</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[13]/a</value>
      <webElementGuid>631a5092-1bbb-47ee-ac3a-3a060f6e4c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'COMPUTER SCIENCE')]</value>
      <webElementGuid>81a19e4c-6fb5-4d78-ac2a-e68fe63014cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ZOOLOGY &amp; MICROBIOLOGY'])[1]/following::a[1]</value>
      <webElementGuid>28a09680-5248-4c31-a63a-82ac48336974</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BIO-CHEMISTRY'])[1]/following::a[2]</value>
      <webElementGuid>e2acd651-b08f-4623-9447-4600ecc6aa6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMATION TECHNOLOGY'])[1]/preceding::a[1]</value>
      <webElementGuid>997bd625-d2c7-4199-8850-a20e0127457f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MBA'])[1]/preceding::a[2]</value>
      <webElementGuid>e6d3c502-09f0-4675-a242-551a55617c62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='COMPUTER SCIENCE']/parent::*</value>
      <webElementGuid>7629a840-61c1-4184-a9cb-1a6e2f4a8871</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/14/computer-science')]</value>
      <webElementGuid>91d7dd58-a94d-400f-a397-552b817dbc84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[13]/a</value>
      <webElementGuid>409caf0c-c234-42cd-a4df-cc5d62a73aad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/14/computer-science' and (text() = 'COMPUTER SCIENCE' or . = 'COMPUTER SCIENCE')]</value>
      <webElementGuid>402d8754-0ada-410d-aa07-1a0a0b944844</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
