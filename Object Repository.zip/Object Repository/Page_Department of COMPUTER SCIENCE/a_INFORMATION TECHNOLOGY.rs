<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_INFORMATION TECHNOLOGY</name>
   <tag></tag>
   <elementGuidId>95ee5125-f7a8-486e-8927-b4bfb215d60c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[14]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(14) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;INFORMATION TECHNOLOGY&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9b2caa0d-f05d-40ad-a59f-d5e666ff634a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>c9268f35-fe35-411d-9a03-ece7089ca6b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/15/information-technology</value>
      <webElementGuid>62d00d2c-c926-467a-84e3-a81a0b8c46a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>INFORMATION TECHNOLOGY</value>
      <webElementGuid>2fc6d4f6-c4a5-4b57-97bc-24ee4433f9cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[14]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>4a75acbe-74b7-4ec8-bf88-8210ad92f580</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[14]/a</value>
      <webElementGuid>126be269-10b8-4dd1-9658-9ba0c9e17cd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'INFORMATION TECHNOLOGY')]</value>
      <webElementGuid>b99fe4af-1424-470c-af6e-377911b5afc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMPUTER SCIENCE'])[1]/following::a[1]</value>
      <webElementGuid>9c98af22-1040-404d-87c7-3dc6bb64f7bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ZOOLOGY &amp; MICROBIOLOGY'])[1]/following::a[2]</value>
      <webElementGuid>be6bab92-f69e-4e5f-8df9-7b2f0260c9f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MBA'])[1]/preceding::a[1]</value>
      <webElementGuid>959afbf2-e377-45ac-b6eb-f8af7601277f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement &amp; VAC Cell'])[2]/preceding::a[2]</value>
      <webElementGuid>69240407-0545-4778-8565-086de22f8fa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='INFORMATION TECHNOLOGY']/parent::*</value>
      <webElementGuid>4026818d-1a26-49f6-b8aa-a4ae79002006</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/15/information-technology')]</value>
      <webElementGuid>3e580fa6-aead-4bfd-8a55-edecd831864b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[14]/a</value>
      <webElementGuid>37d02067-e44b-4523-9ae3-633f61e82d67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/15/information-technology' and (text() = 'INFORMATION TECHNOLOGY' or . = 'INFORMATION TECHNOLOGY')]</value>
      <webElementGuid>a740305a-4af0-4a8f-8a04-84d6506534dc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
