<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ZOOLOGY  MICROBIOLOGY</name>
   <tag></tag>
   <elementGuidId>c90c169d-c411-4207-83ef-80a6bcb9efd5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;ZOOLOGY &amp; MICROBIOLOGY&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>570348f7-edb9-4638-b85a-9ae5cd91a47e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>f3a28ba2-2d5e-4012-a001-3150169cbcec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/13/zoology--microbiology</value>
      <webElementGuid>637a3cba-9656-4b28-9aaa-12f612ce3677</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ZOOLOGY &amp; MICROBIOLOGY</value>
      <webElementGuid>0bd924f7-80b1-499d-9858-f8c9bf207352</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[12]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>8f3b6537-b98e-41c5-9362-bc8cdffa0274</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      <webElementGuid>827a03dd-efd6-426b-a376-098badbb955f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>693d87c9-4671-4282-9745-e91cc09fa718</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BIO-CHEMISTRY'])[1]/following::a[1]</value>
      <webElementGuid>4bf7bdb0-d81d-4200-9af8-b5fbb4ac4d13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MATHEMATICS'])[1]/following::a[2]</value>
      <webElementGuid>11b6086b-a2d5-441a-b19b-f046eb3c6b85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMPUTER SCIENCE'])[1]/preceding::a[1]</value>
      <webElementGuid>59404692-2858-4336-ac7a-84a952911f83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMATION TECHNOLOGY'])[1]/preceding::a[2]</value>
      <webElementGuid>46e2f31b-2085-4c1f-acfa-14482f962241</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='ZOOLOGY &amp; MICROBIOLOGY']/parent::*</value>
      <webElementGuid>2da058d6-451b-4d44-8c71-609e5a1f35df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/13/zoology--microbiology')]</value>
      <webElementGuid>c370e397-4eeb-4179-90a7-fac5103de1a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[12]/a</value>
      <webElementGuid>79ccd498-42c6-4a23-b0d0-6477289dfd1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/13/zoology--microbiology' and (text() = 'ZOOLOGY &amp; MICROBIOLOGY' or . = 'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>28e5736f-5929-4dc9-be3b-128cf42f248a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
