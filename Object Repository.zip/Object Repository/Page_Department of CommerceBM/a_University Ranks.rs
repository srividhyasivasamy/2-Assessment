<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_University Ranks</name>
   <tag></tag>
   <elementGuidId>d2823fa0-3176-4770-94e6-6e6f80aefacd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/div[2]/ul/li[11]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(11) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;University Ranks&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>46b8ced3-4e51-45ea-9390-214bcf38a375</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-current</name>
      <type>Main</type>
      <value>page</value>
      <webElementGuid>e97b5151-ffcd-4248-b782-711912391abe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14</value>
      <webElementGuid>89d1c621-2e7f-4526-82fd-36ccb481c4ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/19/commerce bm#universityranks</value>
      <webElementGuid>35f15f0f-c5cb-471f-811f-e38d285b1355</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>University Ranks</value>
      <webElementGuid>4d3817cb-9359-4c93-8f60-599296c3d75e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[11]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>a7ce0ddb-f4fa-4757-8bf1-22018da4ca58</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/div[2]/ul/li[11]/a</value>
      <webElementGuid>a743bf90-55f2-4fd0-857f-01f342864e49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'University Ranks')]</value>
      <webElementGuid>ca6dfea3-5a7a-48bf-a4f5-76a178fa684c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research Guides'])[1]/following::a[1]</value>
      <webElementGuid>27f72d6f-8c03-48ab-aee3-28b7dc691a15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Funded Projects'])[1]/following::a[2]</value>
      <webElementGuid>04fff318-60de-43b2-a1d1-15b4660af3f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[2]/preceding::a[1]</value>
      <webElementGuid>204ae80e-d932-4fb4-8480-1a7222870860</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNAIDED'])[1]/preceding::a[1]</value>
      <webElementGuid>6c82de80-3dba-45ed-ab6f-220e747e2feb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='University Ranks']/parent::*</value>
      <webElementGuid>87c544b3-af20-4b65-8d99-72e0a4d54fb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/19/commerce bm#universityranks')]</value>
      <webElementGuid>3e3511f8-55d7-4d5b-949c-b62628a56e10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[11]/a</value>
      <webElementGuid>99cd3de5-d228-4819-b56c-9490f9c6f589</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/19/commerce bm#universityranks' and (text() = 'University Ranks' or . = 'University Ranks')]</value>
      <webElementGuid>55bc702a-9598-4bf0-ab6f-37f489822bdd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
