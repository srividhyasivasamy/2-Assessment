<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click Here_1_2_3_4</name>
   <tag></tag>
   <elementGuidId>875f4704-ff10-484c-9c89-93b55ad97c36</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[2]/td[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;1. 27.07.2022 Lecture Series- 1 on Women’s Studies- The Voice of the Voiceless Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6638fa99-2999-4483-bc66-5df7ee3d568e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/1LectureSeries-WomenStudiesonTheVoiceoftheVoiceless.pdf</value>
      <webElementGuid>0b32ca48-2ea7-4798-8346-491eb09d38bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>47231e18-68a3-4941-aeb9-f5d9647a63de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>13c57a94-2edb-4d5f-b6f4-1d6f5031f1ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>2caca132-fee8-4bee-a904-4c7663aa53de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;shadow-sm p-3&quot;]/div[@class=&quot;mt-4&quot;]/div[1]/table[@class=&quot;MsoTable15Grid6ColorfulAccent1&quot;]/tbody[1]/tr[2]/td[4]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>736a63ef-6c33-4a08-a93f-13eec7399c0b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[2]/td[4]/a</value>
      <webElementGuid>92cc60dc-0a6d-4750-98e9-9173b87f81bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click Here')])[5]</value>
      <webElementGuid>aeba2b9e-3833-4467-a767-e25bdbd3d780</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lecture Series- 1 on Women’s Studies- The Voice of the Voiceless'])[1]/following::a[1]</value>
      <webElementGuid>ca93622a-bea1-42a7-a409-b63cf9a349e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report'])[2]/following::a[1]</value>
      <webElementGuid>709f2cfb-c075-4914-ade1-e9897314c0b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[6]/preceding::a[1]</value>
      <webElementGuid>54c471b5-f4f5-4b4a-8a67-6ebc784fda75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/1LectureSeries-WomenStudiesonTheVoiceoftheVoiceless.pdf')]</value>
      <webElementGuid>54f7ae96-ef6d-4efd-bacb-0d78721f048b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//table[4]/tbody/tr[2]/td[4]/a</value>
      <webElementGuid>2be24edd-6646-4868-962e-3a580b616d93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/1LectureSeries-WomenStudiesonTheVoiceoftheVoiceless.pdf' and (text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>4986a5cc-831d-4007-83eb-ffff1a590b3b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
