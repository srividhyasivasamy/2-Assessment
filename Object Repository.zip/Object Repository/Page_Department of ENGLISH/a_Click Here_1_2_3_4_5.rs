<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click Here_1_2_3_4_5</name>
   <tag></tag>
   <elementGuidId>43603e56-bcb1-42d7-911b-2c0feb2fb16d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[7]/td[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(7) > td:nth-of-type(4) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;6. 09.12.2022 Faculty Development Programme on CALL: Diversity in Research &amp; Practice Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2a4b0a7f-0169-4291-a9a5-d91349297721</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/6FDPonCALLDiversityinResearchPractice.pdf</value>
      <webElementGuid>e28f8893-340a-48d1-aa27-cef2ecebe208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>f1578cf7-1a6a-4346-a141-5b92a74bf4e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>23411b24-487a-4263-9318-fba98d65ffdc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>52380f00-418b-44e0-97e1-2a652c15213a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;shadow-sm p-3&quot;]/div[@class=&quot;mt-4&quot;]/div[1]/table[@class=&quot;MsoTable15Grid6ColorfulAccent1&quot;]/tbody[1]/tr[7]/td[4]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>eb37779a-6a92-4a75-ac3f-d65b6e6c8610</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[7]/td[4]/a</value>
      <webElementGuid>3b3e472a-0a16-4e4b-a9d2-eb30348c5313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click Here')])[10]</value>
      <webElementGuid>82b2933b-4d27-4d2f-8f20-8900f22396df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[9]/following::a[1]</value>
      <webElementGuid>7ddfcee9-ff09-4ac9-8efb-f57c9f471133</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Train the Trainers on Unleashing the Global Language'])[2]/preceding::a[1]</value>
      <webElementGuid>eb4e8e19-0b1a-429d-85aa-e7bef0450628</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[11]/preceding::a[1]</value>
      <webElementGuid>b2f05464-44de-4627-b081-8c4a29c9a110</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/6FDPonCALLDiversityinResearchPractice.pdf')]</value>
      <webElementGuid>3b136b4f-7036-4341-8b9f-4fd5274697b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[7]/td[4]/a</value>
      <webElementGuid>07996398-5065-4bf3-8bee-377b0086a2ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/6FDPonCALLDiversityinResearchPractice.pdf' and (text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>d4c84fe0-6895-40fb-a9cb-415bfc0842e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
