<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click Here_1_2_3_4_5_6</name>
   <tag></tag>
   <elementGuidId>2e8d1fbf-9977-4849-8ab7-4334b7d4ef6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[8]/td[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(8) > td:nth-of-type(4) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;7. 20.12.2022 to22.12.2022 Train the Trainers on Unleashing the Global Language Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9789e5bb-aaf2-44e0-a2f1-7f8cb068bb68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/2TraintheTrainersonUnleashingtheGlobalLanguage-02082022to05082022.pdf</value>
      <webElementGuid>3ca84d16-0cc0-4b22-a5fb-e71387957d8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>95532677-7c5b-49c6-b120-0f3d7a26017c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>d4ca9ade-f423-4b62-a546-0df233d14e41</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>7b1ed457-4a41-4a5c-9ff9-3c5786bcbc70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;shadow-sm p-3&quot;]/div[@class=&quot;mt-4&quot;]/div[1]/table[@class=&quot;MsoTable15Grid6ColorfulAccent1&quot;]/tbody[1]/tr[8]/td[4]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>9a9f26e7-0b52-40fb-a31b-6de22ccbae1b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[2]/div/div/div/table[4]/tbody/tr[8]/td[4]/a</value>
      <webElementGuid>3cce2e6c-68f4-4748-8598-0b34931df9b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click Here')])[11]</value>
      <webElementGuid>8807c797-2d79-4c30-8dce-f977e18a0a49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Train the Trainers on Unleashing the Global Language'])[2]/following::a[1]</value>
      <webElementGuid>cfb029ef-5a0e-41ec-a391-87c93f4ade80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[10]/following::a[1]</value>
      <webElementGuid>eaef87c7-9617-4ed0-81da-757a42dc3eb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[12]/preceding::a[1]</value>
      <webElementGuid>20c0a8d2-568d-436e-b11f-e0748c80d69e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/2TraintheTrainersonUnleashingtheGlobalLanguage-02082022to05082022.pdf')])[2]</value>
      <webElementGuid>4626a717-0b0c-4902-94f8-b441b3c143db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[8]/td[4]/a</value>
      <webElementGuid>c0a73777-a4a7-4f04-b6fe-8f94718955d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Activites/English/2022 - 2023/2TraintheTrainersonUnleashingtheGlobalLanguage-02082022to05082022.pdf' and (text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>122d885e-f684-4ea2-90ac-a2414fe1b503</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
