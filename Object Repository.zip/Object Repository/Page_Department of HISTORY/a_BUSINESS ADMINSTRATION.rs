<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_BUSINESS ADMINSTRATION</name>
   <tag></tag>
   <elementGuidId>1ece058f-27e6-42c2-b48b-5eaaf4379a1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;BUSINESS ADMINSTRATION&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>49a195ec-0e4f-4325-895e-a544686c006a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>f78e735a-49ec-4411-ba4a-f255321c154d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/4/business-adminstration</value>
      <webElementGuid>23a4c82f-887c-402b-89eb-8418db90a929</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>BUSINESS ADMINSTRATION</value>
      <webElementGuid>1b46b6b2-cee3-4d0b-81c0-989809490671</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[4]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>1af54376-5b6b-4d1b-a082-ef7773b0c0ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[4]/a</value>
      <webElementGuid>609f806e-9490-42b7-bad8-bc5c8c3b0eec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'BUSINESS ADMINSTRATION')]</value>
      <webElementGuid>c7e33179-a93a-4943-b526-a01fe12589b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HISTORY'])[1]/following::a[1]</value>
      <webElementGuid>d01fb28f-79ae-4f73-85bc-4b2dd8983a28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ENGLISH'])[1]/following::a[2]</value>
      <webElementGuid>06a24ba4-560a-46bb-9556-7cc7edb4663c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMMERCE'])[1]/preceding::a[1]</value>
      <webElementGuid>6084534a-d659-4559-b0d6-d610fabe8018</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BCOM-COMPUTER APPLICATION'])[1]/preceding::a[2]</value>
      <webElementGuid>df31d332-42cb-4670-907f-c2a0e98c61b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='BUSINESS ADMINSTRATION']/parent::*</value>
      <webElementGuid>1bc5e2ef-1dba-4d0d-a867-9914e1e11ef4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/4/business-adminstration')]</value>
      <webElementGuid>fefe44ec-e8c8-4a0e-9152-c60ebe5209db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/ul/li[4]/a</value>
      <webElementGuid>ee4f1ba4-c6c7-4f00-a6a2-e9f0970092e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/4/business-adminstration' and (text() = 'BUSINESS ADMINSTRATION' or . = 'BUSINESS ADMINSTRATION')]</value>
      <webElementGuid>63b3d43d-977c-41e6-9d6b-cc46030069be</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
