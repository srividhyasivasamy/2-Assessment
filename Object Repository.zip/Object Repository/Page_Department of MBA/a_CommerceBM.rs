<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_CommerceBM</name>
   <tag></tag>
   <elementGuidId>0acde214-82b2-4458-b763-9e447172f06d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[17]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(17) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Commerce BM&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>be3f979c-3c77-4a33-80f3-a969b22188a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>c9bdbfda-91f9-4f8d-b65e-db2622f6b39e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/19/commerce bm</value>
      <webElementGuid>a235e922-be84-447e-957f-7795683a6e6d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Commerce BM</value>
      <webElementGuid>d2e38c3c-bdb1-4c6e-bf10-b5f788fb26d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[17]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>e3141758-b89f-4daf-b93e-fb2f6493a1df</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[17]/a</value>
      <webElementGuid>08855607-70cb-4ba1-9cf6-eb18abeec839</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Commerce BM')]</value>
      <webElementGuid>14ea2d7f-b0b3-43ef-a473-b2fbb416d8f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement &amp; VAC Cell'])[2]/following::a[1]</value>
      <webElementGuid>23b784b0-0a1c-4be5-baf3-063c9ac1b38d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MBA'])[1]/following::a[2]</value>
      <webElementGuid>2ff89969-91a1-4fe1-9cbc-dc2b7cf1db52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>e1ac94fd-a0dc-4469-b47f-cfc432b16bb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>31faaacf-bde8-4bb7-ae53-f2ac77de2b41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Commerce BM']/parent::*</value>
      <webElementGuid>fcdba91d-f76c-4893-8260-e959c45d903c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/19/commerce bm')]</value>
      <webElementGuid>b2795ef0-773d-4dfb-8bd8-fd3c0a84b9f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[17]/a</value>
      <webElementGuid>7439111f-3c8f-44dd-ac47-13557c01aec5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/19/commerce bm' and (text() = 'Commerce BM' or . = 'Commerce BM')]</value>
      <webElementGuid>70726405-5bff-4734-90ee-d0323b8860e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
