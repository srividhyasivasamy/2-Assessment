<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ZOOLOGY  MICROBIOLOGY</name>
   <tag></tag>
   <elementGuidId>6df7af6a-dcdd-413e-96f3-129e21c7ac8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;ZOOLOGY &amp; MICROBIOLOGY&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4394c879-34d2-45de-a4a4-c18b15ae3005</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>1c8d1bb4-53c2-4301-9bc4-6dd8819bca3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/13/zoology--microbiology</value>
      <webElementGuid>76e850b0-3dfb-417a-9240-096713525a88</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ZOOLOGY &amp; MICROBIOLOGY</value>
      <webElementGuid>f8143ce0-acba-4e6e-8c2a-ca2b149c125b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[12]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>7aa5f260-7e0a-4a66-a66f-ecba51089e60</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      <webElementGuid>5d419346-75d5-4968-aa94-8ab173af4b1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>b45d9ac2-5088-41d0-afac-c9cda22172f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BIO-CHEMISTRY'])[1]/following::a[1]</value>
      <webElementGuid>8f67ec84-a19c-4262-b0d0-1ad25ac2d303</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MATHEMATICS'])[1]/following::a[2]</value>
      <webElementGuid>d336e948-7f5a-49b6-9fb8-80d9d43ef228</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMPUTER SCIENCE'])[1]/preceding::a[1]</value>
      <webElementGuid>25ae1f4e-fac1-4927-8b47-73ae99fc7b25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMATION TECHNOLOGY'])[1]/preceding::a[2]</value>
      <webElementGuid>96945661-be42-4281-9b72-8feaed8a7fca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='ZOOLOGY &amp; MICROBIOLOGY']/parent::*</value>
      <webElementGuid>42e48607-bc2c-46cc-b7e6-2f1ace2bbc85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/13/zoology--microbiology')]</value>
      <webElementGuid>af73bce9-bff6-4d98-8403-7d4366b64e4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[12]/a</value>
      <webElementGuid>7a3d48a5-b764-4e27-961b-e893fb11d932</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/13/zoology--microbiology' and (text() = 'ZOOLOGY &amp; MICROBIOLOGY' or . = 'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>9ba5370c-415f-4185-88a6-eee69abb8c19</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
