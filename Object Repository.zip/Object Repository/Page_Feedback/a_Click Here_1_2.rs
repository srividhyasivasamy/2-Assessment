<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click Here_1_2</name>
   <tag></tag>
   <elementGuidId>b9f40a1c-d3fb-4be1-b232-75ca16ad0054</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[3]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(3) > td:nth-of-type(2) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;2021 – 2022 Even Semester Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5f004336-9d88-4f41-bbe7-37fe0ad474ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/FeedbackAnalysisReport2021-22EVEN1.pdf</value>
      <webElementGuid>0487a449-4901-4623-ae0a-195551cad67b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>3fa4fb79-1bf3-494d-b4c5-1a1122098727</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>38f4dffb-dcdf-4b2c-8ac2-63703d82b3b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>9da4ac19-7c71-41a5-bf05-11718c047e25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;MsoTable15Plain4&quot;]/tbody[1]/tr[3]/td[2]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>ccd86b9c-c187-40fa-84bc-03c108d3757a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[3]/td[2]/a</value>
      <webElementGuid>923dedff-32f6-414c-a848-964037935a7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click Here')])[3]</value>
      <webElementGuid>379a52eb-5640-430a-a377-eb5d5553192e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[2]/following::a[1]</value>
      <webElementGuid>2ad9c193-de58-4f8a-9eb2-c3d544d79b68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[1]/following::a[2]</value>
      <webElementGuid>1d9934f0-b018-47da-ab39-231e6a63374f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[4]/preceding::a[1]</value>
      <webElementGuid>3a0af883-6c98-45cb-a7df-e3f37607385a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[5]/preceding::a[2]</value>
      <webElementGuid>57da052b-9f30-4e2f-b0cb-114feeecb1e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/FeedbackAnalysisReport2021-22EVEN1.pdf')]</value>
      <webElementGuid>fd27c070-e4fb-4691-bc00-db63394666ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]/a</value>
      <webElementGuid>ff89fb1f-de52-47ef-9c51-7b82b549e11b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/FeedbackAnalysisReport2021-22EVEN1.pdf' and (text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>16c70475-3979-4823-ade2-fdc6ee6c9140</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
