<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click Here_1_2_3_4</name>
   <tag></tag>
   <elementGuidId>78c29506-c027-4838-8c83-207ca3a25abb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[5]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(5) > td:nth-of-type(2) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;2022 – 2023 Even Semester Click Here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3ba8f324-6f90-4fb8-9e15-f8ef14857fdf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/NSCAS-Feedback-2022-2023-EvenSemester.pdf</value>
      <webElementGuid>eeae07d0-ef16-4702-889b-bf10a29866ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>b597ec65-b3e9-41b7-af54-102306b5c05f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>da7ebd90-590e-4be8-9771-7c276c3bdce0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click Here</value>
      <webElementGuid>18495eb0-4366-4266-a8f8-8df2fa167c90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;MsoTable15Plain4&quot;]/tbody[1]/tr[5]/td[2]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>c6138c9b-8c7e-489c-9b32-cf395fb2c3a0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[5]/td[2]/a</value>
      <webElementGuid>ed11b6df-c00a-42ac-9425-6d8a48d88d1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click Here')])[5]</value>
      <webElementGuid>9583bf15-4542-4066-9ff3-80f122ca0bc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[4]/following::a[1]</value>
      <webElementGuid>e5c2d689-e9b1-404e-a440-453d02f1afbd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[3]/following::a[2]</value>
      <webElementGuid>b0d35a5c-ba86-4154-a345-255cee7e362b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>c27f6e60-78c3-4ddd-bff0-4531a395625d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>8098f195-1cfd-4df7-ba5c-1ceb82221378</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/NSCAS-Feedback-2022-2023-EvenSemester.pdf')]</value>
      <webElementGuid>f1359ce5-a0d5-488e-b973-04a9ad13cf89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[5]/td[2]/a</value>
      <webElementGuid>c23632ff-4d87-4256-8a1f-9c8fbd618970</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Feedback/NSCAS-Feedback-2022-2023-EvenSemester.pdf' and (text() = 'Click Here' or . = 'Click Here')]</value>
      <webElementGuid>6f9e8bd1-0077-46cc-ae67-bc95220a23cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
