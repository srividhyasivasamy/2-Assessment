<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Awards Committee</name>
   <tag></tag>
   <elementGuidId>c73ca61b-f909-4302-af3a-3f52f534ea46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li.dropdown > ul > li:nth-of-type(6) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Awards Committee&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9b0bd8c7-5ecd-4dd8-985d-d175f7e42074</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/awards-committee</value>
      <webElementGuid>6c0b99ea-6d58-4691-ae87-5d2daa7a67f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Awards Committee</value>
      <webElementGuid>fc5bdb6b-ec97-4ed7-98f9-0ef7321d8485</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[6]/a[1]</value>
      <webElementGuid>01e4d8dd-0b4e-4946-bd40-8378298972be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li/ul/li[6]/a</value>
      <webElementGuid>1a613ead-4554-40cb-a99c-b5cda92694c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Awards Committee')]</value>
      <webElementGuid>d35131d9-8c5d-4955-ae67-debd1eb9cafe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Finance Committee'])[2]/following::a[1]</value>
      <webElementGuid>d64b1e6e-5ae8-4efa-9669-db92f2be8456</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BoS'])[1]/following::a[2]</value>
      <webElementGuid>2a53fc0e-e930-4319-ba11-40b31e86a771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Non-Statutory Bodies'])[1]/preceding::a[1]</value>
      <webElementGuid>541b56bb-aa11-46e1-8c5c-7872c1c78087</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ICC'])[1]/preceding::a[2]</value>
      <webElementGuid>c35d999e-6e6c-405e-9b9f-0125058c5831</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Awards Committee']/parent::*</value>
      <webElementGuid>be33eae4-d4d1-48e2-804e-0fe446ef0220</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/awards-committee')]</value>
      <webElementGuid>38d04da3-f2dc-4fb1-a5f9-e6367d71765d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li/ul/li[6]/a</value>
      <webElementGuid>7ecc8e0e-0bdb-46c1-850f-ab7b09b8b948</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/awards-committee' and (text() = 'Awards Committee' or . = 'Awards Committee')]</value>
      <webElementGuid>784fd964-684f-49d8-adfe-35cafd9dbcc3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
