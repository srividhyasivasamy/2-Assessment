<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC-Annual Report 2018-2019</name>
   <tag></tag>
   <elementGuidId>7096e626-ecb7-4ae9-bb12-72f446b1ab9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC-Annual Report 2018-2019&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC-Annual Report 2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ac57a31c-740a-4e9f-8cb8-b2002e78cd30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2018-2019.pdf</value>
      <webElementGuid>e7bef241-e999-4994-8eac-ff116de11ee4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2018-2019</value>
      <webElementGuid>b8000ebb-48f5-4327-8368-69eea70327b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>40799466-1c78-4b3e-bf11-a1cf37a8ff48</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2018-2019</value>
      <webElementGuid>318fede0-d562-4ebc-84d9-2d09b31965ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[5]/a[1]</value>
      <webElementGuid>ce9d80c9-52e2-4142-83ee-5aebf0c6e362</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      <webElementGuid>7787a231-8ad7-4a00-bcb9-438a530cb483</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC-Annual Report 2018-2019')]</value>
      <webElementGuid>abb46cc3-1a8f-489d-b377-6517ed4f3ecd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2019-2020'])[1]/following::a[1]</value>
      <webElementGuid>ac3c752f-fd4f-4e29-95fc-e13e3590ec53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2020-2022'])[1]/following::a[2]</value>
      <webElementGuid>dab6519e-0256-4b7e-a04e-9e139ce91680</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>f3781de8-efb4-4d0d-8eee-a65d574ad2d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>79cff62a-5329-44d5-acb4-147327f449cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC-Annual Report 2018-2019']/parent::*</value>
      <webElementGuid>f257783a-b584-4d74-aa9c-18d05b059a93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2018-2019.pdf')]</value>
      <webElementGuid>bdf29547-4f62-4942-ae3c-a585c2f68111</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/a</value>
      <webElementGuid>0b1159ed-ebcf-41b9-a430-d2278ccea15d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2018-2019.pdf' and @title = 'IQAC-Annual Report 2018-2019' and (text() = 'IQAC-Annual Report 2018-2019' or . = 'IQAC-Annual Report 2018-2019')]</value>
      <webElementGuid>711bf0cc-d93a-446a-bba5-d2cd36e27ca8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
