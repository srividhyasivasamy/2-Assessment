<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC-Annual Report 2019-2020</name>
   <tag></tag>
   <elementGuidId>bd36b60d-6483-48ae-a364-9c305c44970e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC-Annual Report 2019-2020&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC-Annual Report 2019-2020&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>15f467f8-e3bd-4b79-9596-8f8779f0eac9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2019-2020.pdf</value>
      <webElementGuid>d6cc678f-3225-49c1-9255-a33d4e7454be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2019-2020</value>
      <webElementGuid>d88dd5de-a402-4810-91ff-eecf54045d8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>30f8ebe6-293f-4dd1-8a78-523c54495542</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2019-2020</value>
      <webElementGuid>25fb9b33-7a7a-4c8d-901d-f7fd81eeca40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[4]/a[1]</value>
      <webElementGuid>7d90aaf9-ea91-406a-82b9-607e41230f41</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      <webElementGuid>125b60c2-9bcb-44b0-9a3d-fb2ceeff2afe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC-Annual Report 2019-2020')]</value>
      <webElementGuid>dce43c06-b798-4dbb-aef2-f5545f81b1d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2020-2022'])[1]/following::a[1]</value>
      <webElementGuid>1643f5ef-9901-4098-8f5c-b6da8ff76c58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2022-2023'])[1]/following::a[2]</value>
      <webElementGuid>22331909-1f87-43eb-b590-a55aa9c6a54e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2018-2019'])[1]/preceding::a[1]</value>
      <webElementGuid>454e4e44-85a4-4a47-9e3f-e3f7b32f62fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>82ce1cc3-0e1d-40e5-826e-8cf6aa38198e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC-Annual Report 2019-2020']/parent::*</value>
      <webElementGuid>a6c6d861-2fd7-49cb-af1d-b6ab89fbc283</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2019-2020.pdf')]</value>
      <webElementGuid>b2be505c-2db3-4dbf-8fe1-aa0f4c7e01d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/a</value>
      <webElementGuid>21c3f026-8890-44b1-b6e7-3348a7a42b26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2019-2020.pdf' and @title = 'IQAC-Annual Report 2019-2020' and (text() = 'IQAC-Annual Report 2019-2020' or . = 'IQAC-Annual Report 2019-2020')]</value>
      <webElementGuid>9538426e-6913-49b6-b506-a3a0980a64a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
