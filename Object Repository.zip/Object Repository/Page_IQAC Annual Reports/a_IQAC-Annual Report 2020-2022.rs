<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC-Annual Report 2020-2022</name>
   <tag></tag>
   <elementGuidId>16aa5b35-bfb5-4c4d-a290-e58d1810435e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC-Annual Report 2020-2022&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC-Annual Report 2020-2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e89235f1-e1f7-4be2-b77b-afa0ababca31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2020-2022.pdf</value>
      <webElementGuid>a3575384-c9eb-4206-a794-e31854d75ed6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2020-2022</value>
      <webElementGuid>4981c1d4-5225-449d-b543-e47d3b546495</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>19a9fc1d-6ab0-4c23-8caa-3a6b701dd7c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2020-2022</value>
      <webElementGuid>78cf2266-8626-4dc6-a016-4bf28cf42f47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[3]/a[1]</value>
      <webElementGuid>85f1cbf0-32d9-4801-a9cf-9e105691cfca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      <webElementGuid>4f864d16-a9b8-4669-9e4c-08a1f134211d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC-Annual Report 2020-2022')]</value>
      <webElementGuid>d886141a-0f32-4237-9ed6-dcd7565800ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2022-2023'])[1]/following::a[1]</value>
      <webElementGuid>278a656a-9f86-475b-81d2-67a71d3ceac2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2023-2024'])[1]/following::a[2]</value>
      <webElementGuid>6846cf4b-8499-46cc-b0fc-4fb8d4b09352</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2019-2020'])[1]/preceding::a[1]</value>
      <webElementGuid>942ae084-7c9f-454e-839f-9683e2dd4cf1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2018-2019'])[1]/preceding::a[2]</value>
      <webElementGuid>939a4336-420d-43f7-b4fa-3efadad15a5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC-Annual Report 2020-2022']/parent::*</value>
      <webElementGuid>26c2a346-15a5-45ed-b75b-f69980ad2fcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2020-2022.pdf')]</value>
      <webElementGuid>66abd2c8-dd1e-42fb-87e4-bec0c330bc4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/a</value>
      <webElementGuid>68913bb5-e314-4cb5-9509-31336d5871a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/Annual-Report-2020-2022.pdf' and @title = 'IQAC-Annual Report 2020-2022' and (text() = 'IQAC-Annual Report 2020-2022' or . = 'IQAC-Annual Report 2020-2022')]</value>
      <webElementGuid>6787c14f-108e-423d-84e7-5c45e70d36ae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
