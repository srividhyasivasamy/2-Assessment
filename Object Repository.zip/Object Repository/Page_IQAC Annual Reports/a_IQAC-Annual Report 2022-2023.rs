<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC-Annual Report 2022-2023</name>
   <tag></tag>
   <elementGuidId>75835aa5-bab7-4b5c-9072-22e75fe1543e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQA-Annual Report 2022-2023&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC-Annual Report 2022-2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>455f518a-0875-45c9-abe2-f74844e1b9f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/AnnualReport-2022-2023.pdf</value>
      <webElementGuid>c7374328-5885-4d05-9d4b-35e90701e415</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQA-Annual Report 2022-2023</value>
      <webElementGuid>1962aa08-1730-469b-b604-ec0e4d670000</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>56590f6f-c6e3-4163-997d-6bfbd7d0ff4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2022-2023</value>
      <webElementGuid>d91703c8-781a-4061-9caf-5b77b175d176</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[2]/a[1]</value>
      <webElementGuid>d3df84af-0699-4cd6-bb18-6037b09d599b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      <webElementGuid>08384b8e-a9eb-4012-9550-6def1d3c9c68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC-Annual Report 2022-2023')]</value>
      <webElementGuid>5e51e475-c899-4bae-83ea-78151d94cc79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2023-2024'])[1]/following::a[1]</value>
      <webElementGuid>c2add771-8f68-4a66-8f2d-b9943b482234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC ANNUAL REPORTS'])[1]/following::a[2]</value>
      <webElementGuid>0b828fe6-6660-4e49-afca-143d366e942f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2020-2022'])[1]/preceding::a[1]</value>
      <webElementGuid>145cd34b-9dbf-4401-b2a8-78ed633b7f42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2019-2020'])[1]/preceding::a[2]</value>
      <webElementGuid>29c3c576-ab00-4798-a44c-5279cfa5b479</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC-Annual Report 2022-2023']/parent::*</value>
      <webElementGuid>e8a69dd2-54a9-40cd-ae29-9e425123ecfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/AnnualReport-2022-2023.pdf')]</value>
      <webElementGuid>0d0a38dd-d6bd-4966-a7de-9ea236c21c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/a</value>
      <webElementGuid>66a3f473-9a81-4510-8ede-d15f05338b58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/AnnualReport-2022-2023.pdf' and @title = 'IQA-Annual Report 2022-2023' and (text() = 'IQAC-Annual Report 2022-2023' or . = 'IQAC-Annual Report 2022-2023')]</value>
      <webElementGuid>3400e3c7-c417-418d-8c38-a9ccc998ff5e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
