<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Orientation  FIP</name>
   <tag></tag>
   <elementGuidId>f459a28a-175d-4fea-8d21-1bf92f9fb334</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(13) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Orientation / FIP&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>99d2c892-174a-487a-a906-fd4bf5c94b4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/orientationfip</value>
      <webElementGuid>750a4c55-ddb9-4071-ad16-77284f6ae303</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Orientation / FIP</value>
      <webElementGuid>5c0b8b0b-ab89-4110-90dc-f8c76ad4b4c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[13]/a[1]</value>
      <webElementGuid>8df69c3b-727e-4f58-97a9-68288e6884b8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      <webElementGuid>f04eb4b0-a354-4c89-99e2-98142f8a2083</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Orientation / FIP')]</value>
      <webElementGuid>ebd776aa-8ce3-49cf-a885-83dff3aa9278</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[1]/following::a[1]</value>
      <webElementGuid>c6865f7a-2655-40c9-8054-23a3bebeb8fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/following::a[2]</value>
      <webElementGuid>3ac9d9e2-5fe2-4d6f-b27e-4ac70a2228f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FDP / PDP'])[1]/preceding::a[1]</value>
      <webElementGuid>ab1d41bc-d25f-4888-8d0f-2d0beae3f4d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Autonomy'])[1]/preceding::a[2]</value>
      <webElementGuid>44c371b5-2f8d-41c1-81db-0fe9266341d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Orientation / FIP']/parent::*</value>
      <webElementGuid>0111115e-18d5-4723-a9cb-64ee0af8d59f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/orientationfip')]</value>
      <webElementGuid>4d3067ab-5b27-4a08-badd-0f1b17504288</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[13]/a</value>
      <webElementGuid>a20333d8-8d1b-494d-a215-4a7144075313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/orientationfip' and (text() = 'Orientation / FIP' or . = 'Orientation / FIP')]</value>
      <webElementGuid>3c21d09d-d300-44fe-a615-032acfea86f2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
