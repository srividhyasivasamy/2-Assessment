<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_EDC cum Earn while you Learn</name>
   <tag></tag>
   <elementGuidId>31bfdb52-b4d5-4603-a2e5-6ab8f610c55f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;EDC cum Earn while you Learn&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6b54432c-880c-4409-8612-85c321f289de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/edc-cum-earn-while-you-learn</value>
      <webElementGuid>b39b95c1-0895-45fb-b812-db1cfc438a1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>EDC cum Earn while you Learn</value>
      <webElementGuid>9c82f771-003f-4f75-b01b-5babe9cdf275</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[6]/a[1]</value>
      <webElementGuid>9e414a13-4644-4a23-8bfa-9cf527257496</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[6]/a</value>
      <webElementGuid>80e5aab4-e5fa-47fa-b5fe-da70cedf7da8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'EDC cum Earn while you Learn')]</value>
      <webElementGuid>626b7aa4-2481-4102-b17e-47bc086e8a97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Committee for Disability Students'])[2]/following::a[1]</value>
      <webElementGuid>e0138074-50c7-4135-b022-18f254d4db63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Women Harassment, Grievance Redressal &amp; Ombudsman'])[1]/following::a[2]</value>
      <webElementGuid>dc990e46-6cba-4cd0-87db-d7b43f776cc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clubs'])[1]/preceding::a[1]</value>
      <webElementGuid>a4b6e82d-9cbb-43a7-973a-2d150046e259</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement &amp; VAC Cell'])[1]/preceding::a[2]</value>
      <webElementGuid>df749558-32ce-47f3-90ab-b7eec2ed6044</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='EDC cum Earn while you Learn']/parent::*</value>
      <webElementGuid>097ecc8a-2af3-48ef-8cd7-de9ffc03383f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/edc-cum-earn-while-you-learn')]</value>
      <webElementGuid>f8b160b2-7d9c-48aa-b67c-78155a723158</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li[2]/ul/li[6]/a</value>
      <webElementGuid>4230b43b-2592-4b77-9a75-5f1f7b659fdb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/edc-cum-earn-while-you-learn' and (text() = 'EDC cum Earn while you Learn' or . = 'EDC cum Earn while you Learn')]</value>
      <webElementGuid>213d044d-d8a3-45d3-b18c-6033652e8bdb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
