<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC - Meeting Minutes - 2018-2019</name>
   <tag></tag>
   <elementGuidId>025839a0-48c2-4341-93cd-a0a9af57ebb1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC - Meeting Minutes - 2018-2019&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC - Meeting Minutes - 2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>97ea5a22-71d1-4622-b948-3f8a121edb28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2018-2019.pdf</value>
      <webElementGuid>6d4d58e5-bbb5-4c49-8fea-5d1aff103927</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2018-2019</value>
      <webElementGuid>c7ffe4dd-3486-4573-b490-ebf52adb87a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2018-2019</value>
      <webElementGuid>a8497b56-8bf5-4873-adf6-01b4afe72c9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[4]/a[1]</value>
      <webElementGuid>470373c5-d6cc-4055-8cdd-f02ca053b24c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[4]/a</value>
      <webElementGuid>702b86c6-73de-43d9-b1ba-bdd047af4951</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC - Meeting Minutes - 2018-2019')]</value>
      <webElementGuid>3790b447-a0dc-449e-a5ce-c77270532bff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2019-2020'])[1]/following::a[1]</value>
      <webElementGuid>48ae5c91-375e-41fe-9159-71891a08e2ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2020-2021'])[1]/following::a[2]</value>
      <webElementGuid>ce91f0e1-7964-424e-96cb-208ccee83eac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>80bf3d49-4b35-4d76-ad88-cf69dd7a675b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>03222473-3c37-44ca-afc2-65ddf1c24514</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC - Meeting Minutes - 2018-2019']/parent::*</value>
      <webElementGuid>39f91458-1448-4897-a981-a2e5a820a255</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2018-2019.pdf')]</value>
      <webElementGuid>392693d6-760d-4735-99ce-38694b6c3441</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/a</value>
      <webElementGuid>5e1221e0-fc70-4360-a48e-fdb76c92a006</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2018-2019.pdf' and @title = 'IQAC - Meeting Minutes - 2018-2019' and (text() = 'IQAC - Meeting Minutes - 2018-2019' or . = 'IQAC - Meeting Minutes - 2018-2019')]</value>
      <webElementGuid>9ab0f82c-e3df-4565-b6c9-a6d6782e5cee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
