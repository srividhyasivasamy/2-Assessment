<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC - Meeting Minutes - 2019-2020</name>
   <tag></tag>
   <elementGuidId>1eede537-f537-46aa-a6a7-6237d636bd3f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC - Meeting Minutes - 2019-2020&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC - Meeting Minutes - 2019-2020&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9dc513df-76fa-4566-8bdc-2f670ceb0729</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2019-2020.pdf</value>
      <webElementGuid>0b22bc63-84c1-4499-9568-51f92d4948cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2019-2020</value>
      <webElementGuid>2951bc7f-a4e5-45a5-90c9-99a0cd434d34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2019-2020</value>
      <webElementGuid>fbf4991c-a238-46fa-9e5a-3e62e4f15312</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[3]/a[1]</value>
      <webElementGuid>e35fb466-f3b8-4dd6-96d3-993bc83fd0af</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      <webElementGuid>484a013c-ee9c-4a46-a210-c6aa1b47e5ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC - Meeting Minutes - 2019-2020')]</value>
      <webElementGuid>3b6862ca-b2db-4727-9b06-e7bffca9086e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2020-2021'])[1]/following::a[1]</value>
      <webElementGuid>bbe2495b-d337-4e9d-b2c6-dbd270d2f2c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2021-2022'])[1]/following::a[2]</value>
      <webElementGuid>e518f5bf-b51e-461e-a0f3-8073da37e700</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2018-2019'])[1]/preceding::a[1]</value>
      <webElementGuid>4fda4e12-9fd5-479b-aec3-ec20eabf3f88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>385ae512-dadb-45a4-8e90-e80393b2f408</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC - Meeting Minutes - 2019-2020']/parent::*</value>
      <webElementGuid>75398c3c-5c45-4a71-8718-7606a03d5c6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2019-2020.pdf')]</value>
      <webElementGuid>64cd8138-0c5e-4b39-87f4-b4d548bbdd6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/a</value>
      <webElementGuid>936fb85a-c43d-4d2b-ad90-dc130bdcb2ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2019-2020.pdf' and @title = 'IQAC - Meeting Minutes - 2019-2020' and (text() = 'IQAC - Meeting Minutes - 2019-2020' or . = 'IQAC - Meeting Minutes - 2019-2020')]</value>
      <webElementGuid>c5bd1dd9-0679-4d4c-bbf0-24fbb141f8f6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
