<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC - Meeting Minutes - 2020-2021</name>
   <tag></tag>
   <elementGuidId>03baebb4-b05b-4547-b756-4a58a635fdc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC - Meeting Minutes - 2020-2021&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC - Meeting Minutes - 2020-2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>63530d31-1fc7-454a-884e-9ab89a408081</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2020-2021.pdf</value>
      <webElementGuid>2491d051-31db-4e64-8a7e-20c3aadb393f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2020-2021</value>
      <webElementGuid>45e66968-ab99-48bc-9b0e-18b6f3353044</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC - Meeting Minutes - 2020-2021</value>
      <webElementGuid>21831193-c083-4d30-ab05-ad9f00400eef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[2]/a[1]</value>
      <webElementGuid>74f57e03-b60a-4010-a613-c9da675fae30</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      <webElementGuid>65d32dcf-5f95-43b1-8961-0fe17a258e4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC - Meeting Minutes - 2020-2021')]</value>
      <webElementGuid>207ef3c6-32d3-4e1b-b3aa-bf838aa0f926</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2021-2022'])[1]/following::a[1]</value>
      <webElementGuid>52554f1d-c8b0-40ca-89d5-31ff54ce67b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MEETING MINUTES'])[1]/following::a[2]</value>
      <webElementGuid>c859771d-39ee-4b34-9d87-3ac250c70623</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2019-2020'])[1]/preceding::a[1]</value>
      <webElementGuid>06f56ebe-68a2-4334-8dda-99c589b18fcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC - Meeting Minutes - 2018-2019'])[1]/preceding::a[2]</value>
      <webElementGuid>39c4639a-721c-4cd6-a224-904ef54a802c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC - Meeting Minutes - 2020-2021']/parent::*</value>
      <webElementGuid>cc39d735-b58e-4ebe-91fe-be2c3a2d9a09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2020-2021.pdf')]</value>
      <webElementGuid>1033b31f-7ca8-445f-bb35-1a883c9991d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/a</value>
      <webElementGuid>e0b4c9c6-a8ca-4c72-bb8a-f728d1c4a605</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC-Meeting Minutes/IQAC-MeetingMinutes-2020-2021.pdf' and @title = 'IQAC - Meeting Minutes - 2020-2021' and (text() = 'IQAC - Meeting Minutes - 2020-2021' or . = 'IQAC - Meeting Minutes - 2020-2021')]</value>
      <webElementGuid>d213f6a4-5d12-4df5-b8c3-3074c34ebf45</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
