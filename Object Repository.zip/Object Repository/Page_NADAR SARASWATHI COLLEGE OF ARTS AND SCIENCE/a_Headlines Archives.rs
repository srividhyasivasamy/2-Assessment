<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Headlines Archives</name>
   <tag></tag>
   <elementGuidId>f8c961e0-32ba-4b3b-b1c6-a5d634de9b91</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[4]/div/div[2]/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Headlines Archives&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>1e7194d6-f7e2-411e-9af5-d3fad4492a72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>873f70fb-6fec-4011-bcfa-f7079e5e64f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Headlines Archives</value>
      <webElementGuid>eecbea83-243a-467d-8df0-06efefd1a9ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;bg-light footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;border-0 shadow card&quot;]/div[@class=&quot;card-body&quot;]/ul[1]/li[5]/a[1]</value>
      <webElementGuid>02da4043-ac4e-47d5-a5d8-bfcc06550c29</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[4]/div/div[2]/ul/li[5]/a</value>
      <webElementGuid>7aa682b3-f71a-4481-961e-bdde6606bf6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Headlines Archives')]</value>
      <webElementGuid>e56c6a26-c351-4c77-a395-98e2c676ba0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAAC'])[3]/following::a[1]</value>
      <webElementGuid>2c1f507e-cd10-4701-b396-0bfff001476d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[2]/following::a[2]</value>
      <webElementGuid>543639f9-a968-472c-84b9-ee4990e3c9e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Events Archives'])[1]/preceding::a[1]</value>
      <webElementGuid>f7bf4f70-8997-47ca-b8d8-8b190311bce9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NSCAS Mail'])[1]/preceding::a[2]</value>
      <webElementGuid>0e49a612-edae-4c5c-98fc-e0178c82ddaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Headlines Archives']/parent::*</value>
      <webElementGuid>052570c9-8495-4391-b415-d14680b21288</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '')])[123]</value>
      <webElementGuid>c76b0958-a9bb-4aa7-b276-6f077f148f78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/ul/li[5]/a</value>
      <webElementGuid>aedaf5ba-830e-4d81-b273-e1e164ac1d17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Headlines Archives' or . = 'Headlines Archives')]</value>
      <webElementGuid>93812a3a-bedf-40df-b0f9-a59e0066ed74</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
