<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NSCAS Newsletter</name>
   <tag></tag>
   <elementGuidId>e93de19c-0454-4292-8e1e-0c8cb02df0c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NSCAS Newsletter&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>45394474-4d93-4fb6-a9ab-60c68ce365d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>1f933e7d-b483-4131-b7f0-d2cb3593d70b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NSCAS Newsletter</value>
      <webElementGuid>28409134-ab10-41e4-8de0-58132bd7396a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;bg-light footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;border-0 shadow card&quot;]/div[@class=&quot;card-body&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>5d9c43e8-cba8-4541-8a63-3cfa3362b941</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li/a</value>
      <webElementGuid>16422587-074d-4721-a21c-9c9faff0b27d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NSCAS Newsletter')]</value>
      <webElementGuid>8e0d8dac-34bf-4f54-8bb3-c2adbfcdda96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/following::a[1]</value>
      <webElementGuid>c760f73d-af9f-40f5-81f8-a7b3879d9ad4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/following::a[1]</value>
      <webElementGuid>c905ccee-0949-4d15-9aae-8b963999c11e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NPTEL'])[1]/preceding::a[1]</value>
      <webElementGuid>b13f35bd-b1f3-4071-ab55-d0e0fe34f864</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Grievances'])[1]/preceding::a[2]</value>
      <webElementGuid>edac8c19-eff2-4839-ac66-9b6edfb0c15b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NSCAS Newsletter']/parent::*</value>
      <webElementGuid>ec5719e0-da97-4b32-a94d-121bff811ed2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '')])[110]</value>
      <webElementGuid>d9855783-f0ed-4dc0-8530-24c23a35512e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]/ul/li/a</value>
      <webElementGuid>cf13aed0-be62-46d5-8848-f56ab28eaa1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'NSCAS Newsletter' or . = 'NSCAS Newsletter')]</value>
      <webElementGuid>5ed7b550-55bb-4e71-b4ba-1a230be1de73</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
