<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Video Tour</name>
   <tag></tag>
   <elementGuidId>bb1c82ad-1855-4478-8be2-58f888082081</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li[7]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.card-body > ul > li:nth-of-type(7) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Video Tour&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>018db29a-16a9-4a32-a4d4-d3a18af193a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>fcb5b5d4-7c0c-4940-8ea4-f08fabbfd689</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Video Tour</value>
      <webElementGuid>170a35ef-b721-4fac-bc14-10c1bac9e7cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;bg-light footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;border-0 shadow card&quot;]/div[@class=&quot;card-body&quot;]/ul[1]/li[7]/a[1]</value>
      <webElementGuid>5348c7a3-288f-4976-837e-ab8e146c6fcf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li[7]/a</value>
      <webElementGuid>1e1b93e7-bc7b-4dab-902c-21d849d61f02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Video Tour')]</value>
      <webElementGuid>c86ac175-607e-4853-8dfa-4c73e4d98a9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alumni Network Portal'])[1]/following::a[1]</value>
      <webElementGuid>914d86dc-ffda-4cf5-9907-d4a5b9b14a68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UGC Job Portal'])[1]/following::a[2]</value>
      <webElementGuid>a950e30c-0d73-45ef-9ab3-657650240a30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Campus Map'])[1]/preceding::a[1]</value>
      <webElementGuid>807bc384-edc9-42d2-8e71-fe41d0308504</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Press Release'])[1]/preceding::a[2]</value>
      <webElementGuid>a79d9dd8-c9ba-4e07-bdbf-6c06c4b27828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Video Tour']/parent::*</value>
      <webElementGuid>cd3d6d5b-97ca-4328-b99f-8d18e4a53e87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '')])[116]</value>
      <webElementGuid>0214336b-0f17-472e-aee1-6ff98f4c2451</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[7]/a</value>
      <webElementGuid>133a33af-9658-4632-9460-870d6c2f062f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Video Tour' or . = 'Video Tour')]</value>
      <webElementGuid>547bbb9e-8681-4ba1-9f05-0cc411723733</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
