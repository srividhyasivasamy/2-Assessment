<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Vision and Mission</name>
   <tag></tag>
   <elementGuidId>c3e06dae-024f-4e60-8b44-4195832a9c88</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[2]/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Vision and Mission&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a211509e-5877-470f-8f5b-3cdf9fbd3392</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/vision-and-mission</value>
      <webElementGuid>181caf90-f8a4-4383-ac31-eacc8449a7d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Vision and Mission</value>
      <webElementGuid>0f1b4de9-fcd8-4292-bfc9-7858deca3a04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[2]/a[1]</value>
      <webElementGuid>684db0c3-5e2a-4d76-bc6d-67c6dfb0b5de</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>177931b1-4bdb-4ad3-a3a9-6a6f9ec3b401</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Vision and Mission')]</value>
      <webElementGuid>bad4528c-2e16-440a-b2bd-9d1c495f5fe2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/following::a[2]</value>
      <webElementGuid>b5a75227-57d7-4e3a-b3f5-ec81f3f68698</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chronology of Events'])[1]/preceding::a[1]</value>
      <webElementGuid>1143e30a-ab66-4461-9834-cce95ff28e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile of the College'])[1]/preceding::a[2]</value>
      <webElementGuid>48dbbd0e-96f8-48cc-bb3f-99dc828f6ea4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Vision and Mission']/parent::*</value>
      <webElementGuid>ba6938f8-b198-4a29-9991-c3caf47a86bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/vision-and-mission')]</value>
      <webElementGuid>a8273e65-5302-426f-b333-ffff3dc7089f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[2]/a</value>
      <webElementGuid>16fe1274-3f38-4ce0-860a-df68220151dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/vision-and-mission' and (text() = 'Vision and Mission' or . = 'Vision and Mission')]</value>
      <webElementGuid>eb6914c2-be08-4c58-831a-a4e827867be5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
