<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_-           -    . ( ,     .       .   _6dbd0e</name>
   <tag></tag>
   <elementGuidId>f328455e-ef41-4bc8-acc6-8a31efe54933</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='பரிமேலழகர் உரை'])[1]/following::div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;கொடுப்பது அழுக்கறுப்பான் சுற்றம் - ஒருவன் பிறர்க்குக் கொடுப்பதன்கண் அழுக்காற்றைச&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>75ef6563-0bbc-432c-acbe-7efc401fe67a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> கொடுப்பது அழுக்கறுப்பான் சுற்றம் - ஒருவன் பிறர்க்குக் கொடுப்பதன்கண் அழுக்காற்றைச் செய்வானது சுற்றம்; உடுப்பதும் உண்பதும் இன்றிக் கெடும் - உடுக்கப்படுவதும் உண்ணப்படுவதும் இன்றிக் கெடும். (கொடுப்பதன்கண் அழுக்கறுத்தலாவது, கொடுக்கப்படும் பொருள்களைப் பற்றிப் பொறாமை செய்தல். 'சுற்றம் கெடும்' எனவே அவன் கேடு சொல்லாமையே பெறப்பட்டது. பிறர் பேறு பொறாமை தன் பேற்றையே அன்றித் தன் சுற்றத்தின் பேற்றையும் இழப்பிக்கும் என்பதாம்.). </value>
      <webElementGuid>7eda032e-2468-4c34-ac3c-62dc0c81bc44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade modal show&quot;]/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;mb-2 row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]</value>
      <webElementGuid>64fce9c1-792a-4dbe-b1ad-25fededb6bfd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='பரிமேலழகர் உரை'])[1]/following::div[2]</value>
      <webElementGuid>d574d37c-39f3-431e-9267-34cc585ffae1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='மு.வரதராசனார் உரை'])[1]/preceding::div[1]</value>
      <webElementGuid>eff0dd80-8710-4242-a2ae-c746d5f2f119</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div</value>
      <webElementGuid>7aadcadc-1bbd-4a4d-919e-a3c0d38f09e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot; கொடுப்பது அழுக்கறுப்பான் சுற்றம் - ஒருவன் பிறர்க்குக் கொடுப்பதன்கண் அழுக்காற்றைச் செய்வானது சுற்றம்; உடுப்பதும் உண்பதும் இன்றிக் கெடும் - உடுக்கப்படுவதும் உண்ணப்படுவதும் இன்றிக் கெடும். (கொடுப்பதன்கண் அழுக்கறுத்தலாவது, கொடுக்கப்படும் பொருள்களைப் பற்றிப் பொறாமை செய்தல். &quot; , &quot;'&quot; , &quot;சுற்றம் கெடும்&quot; , &quot;'&quot; , &quot; எனவே அவன் கேடு சொல்லாமையே பெறப்பட்டது. பிறர் பேறு பொறாமை தன் பேற்றையே அன்றித் தன் சுற்றத்தின் பேற்றையும் இழப்பிக்கும் என்பதாம்.). &quot;) or . = concat(&quot; கொடுப்பது அழுக்கறுப்பான் சுற்றம் - ஒருவன் பிறர்க்குக் கொடுப்பதன்கண் அழுக்காற்றைச் செய்வானது சுற்றம்; உடுப்பதும் உண்பதும் இன்றிக் கெடும் - உடுக்கப்படுவதும் உண்ணப்படுவதும் இன்றிக் கெடும். (கொடுப்பதன்கண் அழுக்கறுத்தலாவது, கொடுக்கப்படும் பொருள்களைப் பற்றிப் பொறாமை செய்தல். &quot; , &quot;'&quot; , &quot;சுற்றம் கெடும்&quot; , &quot;'&quot; , &quot; எனவே அவன் கேடு சொல்லாமையே பெறப்பட்டது. பிறர் பேறு பொறாமை தன் பேற்றையே அன்றித் தன் சுற்றத்தின் பேற்றையும் இழப்பிக்கும் என்பதாம்.). &quot;))]</value>
      <webElementGuid>9b3197e2-f79f-4903-974c-e1178aadf440</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
