<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Century-old philanthropic adminstration</name>
   <tag></tag>
   <elementGuidId>2f32313f-0ad1-44bb-87f8-3d9122bfef34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/div/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.flex-grow-1.p-3.text-justify</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Century-old philanthropic adminstration&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>894b0d98-ddf3-4bfc-8c60-881dc32d4261</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex-grow-1 p-3 text-justify</value>
      <webElementGuid>4f600981-2a28-4748-b726-b552b16f3201</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Century-old philanthropic adminstration</value>
      <webElementGuid>3aaee9a2-215d-4fd2-b7f7-7b2db58f541a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;container py-5&quot;]/div[@class=&quot;row row-cols-md-12&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;d-flex align-items-center  home-top-cour p-0 ps_why_us_box&quot;]/div[@class=&quot;flex-grow-1 p-3 text-justify&quot;]</value>
      <webElementGuid>c3d76178-b68e-42e2-a5ce-72e37acf51fe</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/div/div/div/div[2]</value>
      <webElementGuid>0d719b15-b5c9-4f33-966a-f3840cce8d90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Why NSCAS ?'])[1]/following::div[5]</value>
      <webElementGuid>02ce2f66-282f-48cd-ae3c-9beb93a38ae8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::div[6]</value>
      <webElementGuid>6237d318-583c-4547-b5a0-223d0c67ae39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rural Women Empowerment'])[1]/preceding::div[2]</value>
      <webElementGuid>8b004f2d-ffc6-4349-83c5-9adda0ade052</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement for all'])[1]/preceding::div[6]</value>
      <webElementGuid>9327c49f-6190-4c90-bb3c-4e254c3a95a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Century-old philanthropic adminstration']/parent::*</value>
      <webElementGuid>b4d4a3cc-0210-4de7-bed9-434d1923444f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div/div/div[2]</value>
      <webElementGuid>9740d29a-675a-488a-97c9-a50c017bf7f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Century-old philanthropic adminstration' or . = 'Century-old philanthropic adminstration')]</value>
      <webElementGuid>b57cec6c-74a7-4930-ba43-87c11b33676b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
