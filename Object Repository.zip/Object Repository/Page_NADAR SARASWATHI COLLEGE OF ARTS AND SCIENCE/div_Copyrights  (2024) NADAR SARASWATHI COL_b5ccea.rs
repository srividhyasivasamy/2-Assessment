<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Copyrights  (2024) NADAR SARASWATHI COL_b5ccea</name>
   <tag></tag>
   <elementGuidId>1bde4e5f-7fa2-4ccb-809b-7995c69724ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.copy-right.py-3.text-white > div.row > div.col-md-8</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Copyrights © (2024) NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE. All rights res&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>23897be5-920d-4613-94b3-dd14c1344271</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-8</value>
      <webElementGuid>d9e1c23a-3828-4d21-820b-7050bae09c77</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Copyrights © (2024) NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE. All rights reserved.</value>
      <webElementGuid>bfcda16b-f39e-4ae8-8e0f-8157bb4d5663</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;wed-rights&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;copy-right py-3 text-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-8&quot;]</value>
      <webElementGuid>f2f257e8-9e62-424f-bc4e-e3c960fcf83c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/div/div</value>
      <webElementGuid>d6a74b02-2218-4074-a47b-7954fd210863</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[3]/following::div[5]</value>
      <webElementGuid>680a2776-dfdc-4b0b-8b78-dc7dd5515c1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Mail'])[1]/following::div[5]</value>
      <webElementGuid>09cb3111-4dd8-41ff-b629-4f23b90442a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Peace Soft'])[1]/preceding::div[1]</value>
      <webElementGuid>90957fb3-2351-4f56-ad71-46ec09ac4169</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Copyrights © (']/parent::*</value>
      <webElementGuid>f3753d94-e748-4305-8cde-05da45938789</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div/div/div</value>
      <webElementGuid>9ff9574b-4ffd-4ec7-a998-40cd265798e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Copyrights © (2024) NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE. All rights reserved.' or . = 'Copyrights © (2024) NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE. All rights reserved.')]</value>
      <webElementGuid>580ed6d0-04a8-4c73-b25d-5b290cb37c52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
