<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Designed and Developed by Peace Soft</name>
   <tag></tag>
   <elementGuidId>a734b30b-7650-4537-896e-8d776fc4a505</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.text-end.col-md-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Designed and Developed by Peace Soft&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9df10977-238c-4093-ad0a-fabc807fa243</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-end col-md-4</value>
      <webElementGuid>9695af02-19c6-4a10-86dd-da3e3fde245e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Designed and Developed by Peace Soft</value>
      <webElementGuid>c71e6cae-170c-4b76-b907-f7f074d8abad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;wed-rights&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;copy-right py-3 text-white&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;text-end col-md-4&quot;]</value>
      <webElementGuid>b91f61d4-b9d9-4323-99a5-05797451fb71</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/div/div[2]</value>
      <webElementGuid>717ab5dd-8597-40f9-b4cb-2a011de4dd94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Copyrights © (2024) NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE. All rights reserved.'])[1]/following::div[1]</value>
      <webElementGuid>e7672cfe-cfb6-49ae-84c2-7b728950439f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[3]/following::div[6]</value>
      <webElementGuid>93dc5506-7782-4eb3-8185-4cb12725bf47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Designed and Developed by']/parent::*</value>
      <webElementGuid>9124cea7-346e-43e5-98c9-9b0fbf500932</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div/div/div[2]</value>
      <webElementGuid>57e0604d-b83a-4ec8-ad09-bdca8d3bcd46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Designed and Developed by Peace Soft' or . = 'Designed and Developed by Peace Soft')]</value>
      <webElementGuid>4b97f0e6-2e4d-46e9-a6ce-2d5e465c91f5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
