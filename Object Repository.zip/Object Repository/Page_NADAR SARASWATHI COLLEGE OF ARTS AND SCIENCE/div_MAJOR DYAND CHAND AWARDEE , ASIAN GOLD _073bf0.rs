<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_MAJOR DYAND CHAND AWARDEE , ASIAN GOLD _073bf0</name>
   <tag></tag>
   <elementGuidId>d89a09ad-2e9b-49ed-8f9b-bca0ad858c2d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div/div[2]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.slick-slide.slick-active.slick-current > div > div.px-3 > div.home-top-cour.card > div.card-body > div.border-bottom.pb-2.row > div.col-md-9 > div > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>21ea4045-2ec2-4186-bcbf-cd2b74cbab9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST </value>
      <webElementGuid>d372e59a-ac14-4fbd-95bc-b4ac220dd5b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;slick-slider slick-initialized&quot;]/div[@class=&quot;slick-list&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;slick-slide slick-active slick-current&quot;]/div[1]/div[@class=&quot;px-3&quot;]/div[@class=&quot;home-top-cour  card&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;border-bottom pb-2 row&quot;]/div[@class=&quot;col-md-9&quot;]/div[1]/div[1]</value>
      <webElementGuid>ceaf68df-3a13-4d1d-a879-7ad77d5e1d91</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div/div[2]/div/div</value>
      <webElementGuid>05f21ad2-0eb5-401a-9b37-6cc921daaa47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ms.S.KAVITHA BA'])[1]/following::div[1]</value>
      <webElementGuid>9b37c690-5c29-4a3f-aae4-3af3e348c0a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Founder &amp; CEO, Chanakyaa Network, Chennai'])[1]/following::div[13]</value>
      <webElementGuid>85fa17cd-c52e-4b80-9091-3fa740a7b43b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன்'])[1]/preceding::div[5]</value>
      <webElementGuid>8f3e02d7-0bdc-4d98-b72b-cfbca8a2b52c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='விஜய் TV முதன்மை பட்டிமன்ற பேச்சாளர் , திரைப்பட நடிகர் மற்றும் இயக்குனர்'])[1]/preceding::div[5]</value>
      <webElementGuid>c6372b13-1191-4135-a2a4-bd47cb8b80b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST']/parent::*</value>
      <webElementGuid>4f1fd390-336a-4808-954b-e6fa38888558</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div/div[2]/div/div</value>
      <webElementGuid>442320bd-63f4-4496-ae63-55918f22e28e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST ' or . = 'MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST ')]</value>
      <webElementGuid>64b5bcbe-78f6-46b5-9f8a-5d3a2525b17f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
