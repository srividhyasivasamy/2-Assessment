<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Our vision is to produce competent, dis_a37962</name>
   <tag></tag>
   <elementGuidId>ba59c816-f08b-4735-9635-a5faba062ef6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/div[2]/div/div/div/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-12.home-top-cour-desc > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Our vision is to produce competent, disciplined matured citizen, scientists and &quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>18fc0abf-6f8c-4c0d-a1ba-d71724c9f08b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Our vision is to produce competent, disciplined matured citizen, scientists and administrators with high moral, ethical and professional standards.</value>
      <webElementGuid>91938bd9-7720-4d82-946f-a134906b7e91</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/div[@class=&quot;container pb-2&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;home-top-cour px-4 vision_box&quot;]/div[@class=&quot;col-md-12 home-top-cour-desc&quot;]/div[1]</value>
      <webElementGuid>63461ee1-abd5-4a82-a0a4-d814246a9625</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/div[2]/div/div/div/div/div/div/div</value>
      <webElementGuid>67c95e42-4fcc-4983-acf0-30308cdcbbee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/following::div[1]</value>
      <webElementGuid>a0402fd7-8e0b-4dad-b56a-4670539ffda3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reinforcing students as responsible citizens'])[1]/following::div[8]</value>
      <webElementGuid>59a5157d-8af6-46fa-8332-506779a05acd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mission'])[1]/preceding::div[1]</value>
      <webElementGuid>94298f0a-342d-49cd-a790-8645fe12fdff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='To create and sustain an academic environment conducive to academic excellence.'])[1]/preceding::div[1]</value>
      <webElementGuid>fd5d2a5a-911a-4adf-9ba2-475ab5fa42db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Our vision is to produce competent, disciplined matured citizen, scientists and administrators with high moral, ethical and professional standards.']/parent::*</value>
      <webElementGuid>01fde871-c3b7-4214-bedb-3defa5a4c40c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div/div</value>
      <webElementGuid>b9043e84-01c8-495f-ab58-87a492f74a19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Our vision is to produce competent, disciplined matured citizen, scientists and administrators with high moral, ethical and professional standards.' or . = 'Our vision is to produce competent, disciplined matured citizen, scientists and administrators with high moral, ethical and professional standards.')]</value>
      <webElementGuid>a243d435-609a-427a-8390-4e1deda6bcac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
