<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Placement for all</name>
   <tag></tag>
   <elementGuidId>bcf94b56-12ee-41c5-8dda-2385623ae847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/div/div[3]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Placement for all&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0a55e5c7-49ba-4e8c-a1e6-6773ea8330ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex-grow-1 p-3 text-justify</value>
      <webElementGuid>1b0f5c44-b051-4449-8085-b5a311c96279</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Placement for all</value>
      <webElementGuid>3e7b28b1-12a4-4160-bcbb-42c284519d41</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;container py-5&quot;]/div[@class=&quot;row row-cols-md-12&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;d-flex align-items-center  home-top-cour p-0 ps_why_us_box&quot;]/div[@class=&quot;flex-grow-1 p-3 text-justify&quot;]</value>
      <webElementGuid>fa08fd26-4dd7-4686-8846-707011a3a5d2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/div/div[3]/div/div[2]</value>
      <webElementGuid>55fe92f0-5291-4652-b377-daef02383e23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rural Women Empowerment'])[1]/following::div[4]</value>
      <webElementGuid>dcc43d22-96f7-4c16-9950-2633a39e9ee2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Century-old philanthropic adminstration'])[1]/following::div[8]</value>
      <webElementGuid>53a084c5-0732-4f72-a6fc-4487fdc6bacc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reinforcing students as responsible citizens'])[1]/preceding::div[2]</value>
      <webElementGuid>5b4cfd97-b9ab-44f0-aeb6-8e2d0b978fa4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::div[5]</value>
      <webElementGuid>a84b83b8-8141-4384-a50e-30973dd9533d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Placement for all']/parent::*</value>
      <webElementGuid>9d60020b-2409-4d20-943c-6c6c52c21d67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]</value>
      <webElementGuid>dd0defe6-0431-4435-9936-969e630ca38c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Placement for all' or . = 'Placement for all')]</value>
      <webElementGuid>692f6169-5103-4a5e-800c-ecbd5b5cf269</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
