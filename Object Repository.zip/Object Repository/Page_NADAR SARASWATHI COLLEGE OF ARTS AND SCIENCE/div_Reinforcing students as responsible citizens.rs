<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Reinforcing students as responsible citizens</name>
   <tag></tag>
   <elementGuidId>dd8ee827-851a-4d42-a5e3-aa4f6d281a72</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/div/div[4]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Reinforcing students as responsible citizens&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>01cbe13f-df4b-4f4c-87b8-a51a397e6b2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex-grow-1 p-3 text-justify</value>
      <webElementGuid>7da783fe-0a7f-4328-9864-cd574e657dcc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Reinforcing students as responsible citizens</value>
      <webElementGuid>78a052e9-0aa7-4753-84eb-a4c50323ee09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;container py-5&quot;]/div[@class=&quot;row row-cols-md-12&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;d-flex align-items-center  home-top-cour p-0 ps_why_us_box&quot;]/div[@class=&quot;flex-grow-1 p-3 text-justify&quot;]</value>
      <webElementGuid>992e49b4-a122-4627-b34c-240fd6a31be6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/div/div[4]/div/div[2]</value>
      <webElementGuid>88706306-117d-4a91-81d2-a16bd1f27b07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement for all'])[1]/following::div[4]</value>
      <webElementGuid>86efb4f1-c480-4c80-9a3f-63dd5476c40f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rural Women Empowerment'])[1]/following::div[8]</value>
      <webElementGuid>7bae7d2a-cf8c-4a07-834c-5e4a560afe8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::div[1]</value>
      <webElementGuid>5b8a2f9b-574f-42bf-bc59-bfc4b202f8f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mission'])[1]/preceding::div[5]</value>
      <webElementGuid>5e6b5526-674f-4122-a7ce-ad93003a8b04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Reinforcing students as responsible citizens']/parent::*</value>
      <webElementGuid>b25f5280-9ea6-4834-9e99-885503a53455</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]</value>
      <webElementGuid>95365b57-11ca-4fd0-a71e-e0eea396fc40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Reinforcing students as responsible citizens' or . = 'Reinforcing students as responsible citizens')]</value>
      <webElementGuid>6b959460-6e63-4b9c-aadd-9d41048cdc82</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
