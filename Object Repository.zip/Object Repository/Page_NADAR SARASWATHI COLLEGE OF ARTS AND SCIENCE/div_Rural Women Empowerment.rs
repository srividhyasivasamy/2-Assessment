<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Rural Women Empowerment</name>
   <tag></tag>
   <elementGuidId>3b024843-13e4-49a4-80a6-ad151d0e6e29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/div/div[2]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Rural Women Empowerment&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>576228e6-5b3a-43d8-b6fe-6b059c69d004</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex-grow-1 p-3 text-justify</value>
      <webElementGuid>2a86f00f-6739-4993-9264-b5ad60be5bc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Rural Women Empowerment</value>
      <webElementGuid>9b4b096f-f74d-47e6-9e27-3527e7812d11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;container py-5&quot;]/div[@class=&quot;row row-cols-md-12&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;d-flex align-items-center  home-top-cour p-0 ps_why_us_box&quot;]/div[@class=&quot;flex-grow-1 p-3 text-justify&quot;]</value>
      <webElementGuid>543ad640-2c71-40cd-8cf7-97c16ed36d3b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/div/div[2]/div/div[2]</value>
      <webElementGuid>ea895fde-8318-4bc0-ba86-ce4cc5c861b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Century-old philanthropic adminstration'])[1]/following::div[4]</value>
      <webElementGuid>2c75a95d-db37-4760-83e0-214611fc6193</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Why NSCAS ?'])[1]/following::div[9]</value>
      <webElementGuid>996255e7-d7b0-41c2-9f5a-b4a3cdc03d62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement for all'])[1]/preceding::div[2]</value>
      <webElementGuid>f25eb296-5027-47f3-9dd5-781979ca31f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reinforcing students as responsible citizens'])[1]/preceding::div[6]</value>
      <webElementGuid>2202cece-7271-4df3-880a-55300d5c5c86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Rural Women Empowerment']/parent::*</value>
      <webElementGuid>8ea2520d-6a34-4ef6-b497-d90ff7b81862</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div[2]/div/div[2]</value>
      <webElementGuid>41acba66-c063-4267-8834-4cd91132ac80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Rural Women Empowerment' or . = 'Rural Women Empowerment')]</value>
      <webElementGuid>38b91e2a-97b5-486a-afab-b701c82e8687</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
