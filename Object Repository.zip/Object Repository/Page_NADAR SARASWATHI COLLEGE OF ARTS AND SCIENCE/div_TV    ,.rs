<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_TV    ,</name>
   <tag></tag>
   <elementGuidId>441ae473-d30a-4ed6-93a3-fb669af17c33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[8]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(8) > div > .px-3 > .home-top-cour</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a126b0e3-f831-4d9c-bb1e-a6dcc38eadce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>home-top-cour  card</value>
      <webElementGuid>ca3b5f8b-1111-4b6c-a6ab-520dfd6ad3cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன் விஜய் TV முதன்மை பட்டிமன்ற பேச்சாளர் , திரைப்பட நடிகர் மற்றும் இயக்குனர்உழைப்பால் உயர்ந்த உள்ளங்களை சந்தித்தேன் ..&#xd;
இவர்கள் போல் உழைத்திட உள்ளதால் சிந்தித்தேன் !&#xd;
கற்கண்டு சொற்கொண்டு வண்ண தமிழுக்கு வளைகாப்பு நடத்தும் &#xd;
அனைத்து பெருமக்களுக்கும் ....வணக்கம் ! வாழ்த்துகள் !</value>
      <webElementGuid>68e1f808-e46c-414a-9848-04e079f1cd37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;slick-slider slick-initialized&quot;]/div[@class=&quot;slick-list&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;slick-slide slick-active&quot;]/div[1]/div[@class=&quot;px-3&quot;]/div[@class=&quot;home-top-cour  card&quot;]</value>
      <webElementGuid>03bd623b-ab1a-4dc3-b61f-e92567a2f240</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[8]/div/div/div</value>
      <webElementGuid>c21f4fbf-9377-4bdf-af26-1cbe3d6f9d57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST'])[1]/following::div[7]</value>
      <webElementGuid>b0561e2f-ec3a-4fe5-9a3a-03c9d5909acc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ms.S.KAVITHA BA'])[1]/following::div[8]</value>
      <webElementGuid>f54a027c-e0f8-4780-b18e-fe864d7030ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/div</value>
      <webElementGuid>52845baf-1fbc-4971-bc2a-d67aa04ab747</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன் விஜய் TV முதன்மை பட்டிமன்ற பேச்சாளர் , திரைப்பட நடிகர் மற்றும் இயக்குனர்உழைப்பால் உயர்ந்த உள்ளங்களை சந்தித்தேன் ..&#xd;
இவர்கள் போல் உழைத்திட உள்ளதால் சிந்தித்தேன் !&#xd;
கற்கண்டு சொற்கொண்டு வண்ண தமிழுக்கு வளைகாப்பு நடத்தும் &#xd;
அனைத்து பெருமக்களுக்கும் ....வணக்கம் ! வாழ்த்துகள் !' or . = 'திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன் விஜய் TV முதன்மை பட்டிமன்ற பேச்சாளர் , திரைப்பட நடிகர் மற்றும் இயக்குனர்உழைப்பால் உயர்ந்த உள்ளங்களை சந்தித்தேன் ..&#xd;
இவர்கள் போல் உழைத்திட உள்ளதால் சிந்தித்தேன் !&#xd;
கற்கண்டு சொற்கொண்டு வண்ண தமிழுக்கு வளைகாப்பு நடத்தும் &#xd;
அனைத்து பெருமக்களுக்கும் ....வணக்கம் ! வாழ்த்துகள் !')]</value>
      <webElementGuid>86da7eb1-53da-4f44-ba82-5b8b818a399d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
