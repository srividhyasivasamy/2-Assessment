<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_To navigate, press the arrow keys</name>
   <tag></tag>
   <elementGuidId>d0c3dc4f-7d64-4913-87c5-534a982ecbd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mapDiv']/div/div[3]/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.gm-style > div > div:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=/^To navigate, press the arrow keys\.$/ >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>904112f4-068b-41d1-801b-19ecb71d0abb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>To navigate, press the arrow keys.</value>
      <webElementGuid>2620af46-f50c-4131-ae5a-33410bebafd1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mapDiv&quot;)/div[1]/div[@class=&quot;gm-style&quot;]/div[1]/div[2]</value>
      <webElementGuid>0599f24d-fe30-4969-a73e-312bb664ab17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_NADAR SARASWATHI COLLEGE OF ARTS AND SCIENCE/iframe_1</value>
      <webElementGuid>d4da465f-7b4a-417c-b03b-782a8f0a3fff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mapDiv']/div/div[3]/div/div[2]</value>
      <webElementGuid>5be56141-a702-4700-b02d-8a3f14ce2ea8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Jump down by 75%'])[1]/following::div[24]</value>
      <webElementGuid>c1510798-0bdf-4238-952b-957303ec44c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Page Down'])[1]/following::div[24]</value>
      <webElementGuid>ca359cc0-b187-4028-8d7c-d04422668f67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View larger map'])[1]/preceding::div[8]</value>
      <webElementGuid>701b3b63-6549-4bd9-87aa-e5fcb054d82c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]</value>
      <webElementGuid>994104e1-9a43-40d4-aec9-f808fba2ec70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'To navigate, press the arrow keys.' or . = 'To navigate, press the arrow keys.')]</value>
      <webElementGuid>babac895-c7d6-4227-be87-79f9767d12bc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
