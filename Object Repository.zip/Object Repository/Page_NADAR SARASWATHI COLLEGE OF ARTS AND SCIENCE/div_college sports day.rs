<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_college sports day</name>
   <tag></tag>
   <elementGuidId>3ce8fb52-8ea1-4b0b-a0d6-b7102d842409</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div[2]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.slick-slide.slick-active.slick-current > div > div.px-3 > div.home-top-cour.card > div.card-body > div.mt-3.row > div.col-md-12 > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;நாடார் சரசுவதி college sports day மிகவும் அருமையாகவும் சிறப்பாகவும் இருந்தது. மி&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d0afaa0a-d4c7-49bd-bc3d-8fa171b9eb9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>நாடார் சரசுவதி college sports day மிகவும் அருமையாகவும் சிறப்பாகவும் இருந்தது. மிகவும் அருமையான நிர்வாகம்.அவர்களின் குழுமம் மேலும் வளர இறைவனை வேண்டிக்கொள்கிறேன்.</value>
      <webElementGuid>b57377c7-1d0f-493d-bd19-cd18f2bd6ea8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;slick-slider slick-initialized&quot;]/div[@class=&quot;slick-list&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;slick-slide slick-active slick-current&quot;]/div[1]/div[@class=&quot;px-3&quot;]/div[@class=&quot;home-top-cour  card&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;mt-3 row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]</value>
      <webElementGuid>cc4592a2-df64-4e9a-8ba0-28c2bf733219</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div[2]/div/div</value>
      <webElementGuid>92f239f3-c4e3-4f89-9ee9-3a491745302d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST'])[1]/following::div[3]</value>
      <webElementGuid>3e00c1b9-9fae-4dc9-aecd-1623ac722a24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ms.S.KAVITHA BA'])[1]/following::div[4]</value>
      <webElementGuid>7e9fb0f9-50be-408c-ad30-eb83d3f7079c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன்'])[1]/preceding::div[2]</value>
      <webElementGuid>5e1eb129-d215-440c-ab15-58aac787ae39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='விஜய் TV முதன்மை பட்டிமன்ற பேச்சாளர் , திரைப்பட நடிகர் மற்றும் இயக்குனர்'])[1]/preceding::div[2]</value>
      <webElementGuid>f3b357f7-be30-49e7-8c68-4ccf69ea62b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='நாடார் சரசுவதி college sports day மிகவும் அருமையாகவும் சிறப்பாகவும் இருந்தது. மிகவும் அருமையான நிர்வாகம்.அவர்களின் குழுமம் மேலும் வளர இறைவனை வேண்டிக்கொள்கிறேன்.']/parent::*</value>
      <webElementGuid>66553e5b-d44c-4132-8dcd-dfd4cd88b498</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div[2]/div/div</value>
      <webElementGuid>30e2f9b8-94ee-4e76-86e0-11ce06a7d0f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'நாடார் சரசுவதி college sports day மிகவும் அருமையாகவும் சிறப்பாகவும் இருந்தது. மிகவும் அருமையான நிர்வாகம்.அவர்களின் குழுமம் மேலும் வளர இறைவனை வேண்டிக்கொள்கிறேன்.' or . = 'நாடார் சரசுவதி college sports day மிகவும் அருமையாகவும் சிறப்பாகவும் இருந்தது. மிகவும் அருமையான நிர்வாகம்.அவர்களின் குழுமம் மேலும் வளர இறைவனை வேண்டிக்கொள்கிறேன்.')]</value>
      <webElementGuid>ce4849f8-2859-42fe-9b78-23db65a4fb0b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
