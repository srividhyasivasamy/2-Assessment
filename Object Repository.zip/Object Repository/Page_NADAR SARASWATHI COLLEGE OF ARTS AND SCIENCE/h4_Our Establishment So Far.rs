<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Our Establishment So Far</name>
   <tag></tag>
   <elementGuidId>b2a776af-2268-45ee-bca9-92c9db980858</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/div[3]/section/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.d-none.d-sm-block > section.py-4 > div.container > h4.text-center.fw-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Our Establishment So Far&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>b2f75575-324c-4258-83c9-2eb6c8220eb2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-center fw-bold</value>
      <webElementGuid>46fc238e-82e5-441d-a3a5-f399f587fc1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Our Establishment So Far</value>
      <webElementGuid>d75f11a7-1985-4b63-9f63-e25182e6a430</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/div[@class=&quot;d-none d-sm-block&quot;]/section[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/h4[@class=&quot;text-center fw-bold&quot;]</value>
      <webElementGuid>6e69d3f5-6947-45f2-bb21-424dde8235be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/div[3]/section/div/h4</value>
      <webElementGuid>8e5fd941-9bcd-42cf-877d-33252f20d2a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More..'])[1]/following::h4[1]</value>
      <webElementGuid>c8b5bad7-754a-4691-8f54-cc571490606d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='விளக்கம்:'])[1]/following::h4[1]</value>
      <webElementGuid>79187a3c-3502-4ef4-bc23-52cf57ef6268</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Years'])[1]/preceding::h4[1]</value>
      <webElementGuid>4c2a9d36-9560-4a3a-9a5b-51ecd9b62a32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Awards and Honors'])[1]/preceding::h4[1]</value>
      <webElementGuid>f2e7b031-a997-45ae-8bd8-fa2658dfc880</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Our Establishment So Far']/parent::*</value>
      <webElementGuid>d35ca654-ee30-4fb8-abb0-1713803510b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/section/div/h4</value>
      <webElementGuid>12b29d47-19d8-49dc-9d40-d87be22c331c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Our Establishment So Far' or . = 'Our Establishment So Far')]</value>
      <webElementGuid>4b1afe17-3515-4d39-9151-5ffb53730178</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
