<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Thought of The Day</name>
   <tag></tag>
   <elementGuidId>85ec57fd-986c-494a-87b8-db90a26a3e90</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/h4</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h4.text-center.fw-bold.mb-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Thought of The Day&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
      <webElementGuid>c1b96ebb-9ff2-43ec-8e1a-d52ad45aed96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-center fw-bold mb-4</value>
      <webElementGuid>db70e880-9824-412e-baa6-b34cc4592b32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Thought of The Day</value>
      <webElementGuid>7bcc31b9-47c1-43d7-aaf5-cee32f66d5b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;px-3 py-4&quot;]/div[@class=&quot;container&quot;]/h4[@class=&quot;text-center fw-bold mb-4&quot;]</value>
      <webElementGuid>2b45bdf3-f6d8-4e81-921c-70c0a96c6770</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/h4</value>
      <webElementGuid>00bbadc6-b683-4bea-8841-1bafc0e5ae2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Announcements'])[1]/following::h4[1]</value>
      <webElementGuid>120d779e-25a7-422d-a9cb-5e0c133563ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Empowering Women'])[1]/following::h4[1]</value>
      <webElementGuid>90a6e9b0-dcf3-4428-a5f2-ae9708f065fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Thought of The Day']/parent::*</value>
      <webElementGuid>e22ca556-2353-488e-a96f-55960ea040ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h4</value>
      <webElementGuid>c5722e92-f8b2-4c30-842a-73a65988f17e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h4[(text() = 'Thought of The Day' or . = 'Thought of The Day')]</value>
      <webElementGuid>c7166ff7-6eb6-4cff-b1d8-902d3d227e1e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
