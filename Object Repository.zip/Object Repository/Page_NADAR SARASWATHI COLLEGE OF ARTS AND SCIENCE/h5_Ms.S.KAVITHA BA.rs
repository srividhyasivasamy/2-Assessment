<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_Ms.S.KAVITHA BA</name>
   <tag></tag>
   <elementGuidId>b684d037-0786-436b-8fc7-48c14c197ab2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div/div[2]/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.slick-slide.slick-active.slick-current > div > div.px-3 > div.home-top-cour.card > div.card-body > div.border-bottom.pb-2.row > div.col-md-9 > div > h5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Ms.S.KAVITHA BA&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>e9c4ed85-0d2b-4be2-8260-84f4dcc46d62</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ms.S.KAVITHA BA </value>
      <webElementGuid>0b38165e-3ba9-434c-921b-8c1b4299d82a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;slick-slider slick-initialized&quot;]/div[@class=&quot;slick-list&quot;]/div[@class=&quot;slick-track&quot;]/div[@class=&quot;slick-slide slick-active slick-current&quot;]/div[1]/div[@class=&quot;px-3&quot;]/div[@class=&quot;home-top-cour  card&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;border-bottom pb-2 row&quot;]/div[@class=&quot;col-md-9&quot;]/div[1]/h5[1]</value>
      <webElementGuid>ca65878f-2601-4aae-9142-0df5c70f3476</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[3]/div/div/div/div/div[7]/div/div/div/div/div/div[2]/div/h5</value>
      <webElementGuid>09dd3afb-cc42-4406-a292-300e5d9863c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Founder &amp; CEO, Chanakyaa Network, Chennai'])[1]/following::h5[1]</value>
      <webElementGuid>969ac93b-04af-4f29-99e9-27f326239946</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mr.R.Rangaraj Pandey'])[1]/following::h5[1]</value>
      <webElementGuid>5b084873-486c-4b9c-92c3-6e4a0151422f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MAJOR DYAND CHAND AWARDEE , ASIAN GOLD MEDALIST'])[1]/preceding::h5[1]</value>
      <webElementGuid>1158ab45-d978-41b0-92b8-c351add01c28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='திரு. தமிழ்ப்பேச்சு .ராஜ்மோகன்'])[1]/preceding::h5[1]</value>
      <webElementGuid>40754df0-5c1d-4377-a6c6-4caab5af9a59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ms.S.KAVITHA BA']/parent::*</value>
      <webElementGuid>1359e231-d05c-4de1-b208-f29fe17f8c1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div/div[2]/div/h5</value>
      <webElementGuid>4e478d61-d2ce-41af-98c4-77aa60261a3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'Ms.S.KAVITHA BA ' or . = 'Ms.S.KAVITHA BA ')]</value>
      <webElementGuid>212f2654-5719-4c11-8535-31caa564b8a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
