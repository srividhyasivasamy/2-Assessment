<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img_Gallery_d-block ms-auto me-auto w-100</name>
   <tag></tag>
   <elementGuidId>2a38ac43-57f0-4417-8647-5b37d8140d23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/div/div/div[2]/div[2]/img</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.active.carousel-item > img.d-block.ms-auto.me-auto.w-100</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=img[name=&quot;First slide&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>08ea5cc3-a1e7-4dfe-b535-71bc52fdadca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-block ms-auto me-auto w-100</value>
      <webElementGuid>9773bc78-4cbe-4f40-a44e-bd983de22f57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WebsiteSliders/admission-slide-2425.jpg</value>
      <webElementGuid>187763a2-8eef-4327-bf22-28f172e7fccc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>alt</name>
      <type>Main</type>
      <value>First slide</value>
      <webElementGuid>0d17f6d4-f48e-4e3c-b151-c4237a0b54ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/div[@class=&quot;ps__home__slider&quot;]/div[@class=&quot;carousel slide&quot;]/div[@class=&quot;carousel-inner&quot;]/div[@class=&quot;active carousel-item&quot;]/img[@class=&quot;d-block ms-auto me-auto w-100&quot;]</value>
      <webElementGuid>a4411ecc-81fe-4862-927f-f4998161618b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/div/div/div[2]/div[2]/img</value>
      <webElementGuid>5c788315-ad4f-4d7f-809c-a85eadec9dc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>(//img[@alt='First slide'])[2]</value>
      <webElementGuid>dc6f01de-feaf-48bd-bc94-512bbaa93f27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/img</value>
      <webElementGuid>b07b5037-b119-4ec9-8e54-7f78e01c2e2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//img[@src = 'https://nscollege.org.in/files_list/nscas/fm/WebsiteSliders/admission-slide-2425.jpg' and @alt = 'First slide']</value>
      <webElementGuid>9c13e9ce-e233-4a6a-8f4f-ed58e8417995</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
