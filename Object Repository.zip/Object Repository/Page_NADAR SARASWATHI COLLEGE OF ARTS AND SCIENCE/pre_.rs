<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>pre_</name>
   <tag></tag>
   <elementGuidId>d25eb264-4d5f-41c6-a97e-3fa166b8b52e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='குறள்'])[1]/following::pre[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-12 > div > pre</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=dialog >> internal:text=&quot;கொடுப்பது அழுக்கறுப்பான் சுற்றம் உடுப்பதூஉம் உண்பதூஉம் இன்றிக் கெடும்.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>pre</value>
      <webElementGuid>795a983f-eb9a-4c35-b453-6d987bd2f738</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>கொடுப்பது அழுக்கறுப்பான் சுற்றம் உடுப்பதூஉம்
உண்பதூஉம் இன்றிக் கெடும். </value>
      <webElementGuid>fe425485-93a4-41f6-ad44-5534a7121911</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade modal show&quot;]/div[@class=&quot;modal-dialog modal-lg&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;mb-2 row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/pre[1]</value>
      <webElementGuid>4f1eb50b-3ef9-4495-93c3-b01a20d72ed9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='குறள்'])[1]/following::pre[1]</value>
      <webElementGuid>750eb890-9bce-44b2-875f-f0832cf64342</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='அழுக்காறாமை'])[1]/following::pre[1]</value>
      <webElementGuid>faccdd47-8bb5-4b2a-b2ea-64d35d0d2e64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='பரிமேலழகர் உரை'])[1]/preceding::pre[1]</value>
      <webElementGuid>7f3a5cb7-c834-4eb8-8aeb-03a7e40e8034</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='மு.வரதராசனார் உரை'])[1]/preceding::pre[1]</value>
      <webElementGuid>e2951c09-2bbe-4c59-af1b-c34a68a8b0b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/pre</value>
      <webElementGuid>911c40d7-9421-495b-9b8f-6719c1f512ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//pre[(text() = 'கொடுப்பது அழுக்கறுப்பான் சுற்றம் உடுப்பதூஉம்
உண்பதூஉம் இன்றிக் கெடும். ' or . = 'கொடுப்பது அழுக்கறுப்பான் சுற்றம் உடுப்பதூஉம்
உண்பதூஉம் இன்றிக் கெடும். ')]</value>
      <webElementGuid>89511f57-376f-4f6d-b8eb-f3b2112cb362</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
