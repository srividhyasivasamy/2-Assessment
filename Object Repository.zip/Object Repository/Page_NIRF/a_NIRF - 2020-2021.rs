<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NIRF - 2020-2021</name>
   <tag></tag>
   <elementGuidId>2e353c47-719d-4ff7-b742-7b972dcb9077</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;NIRF - 2020-2021&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NIRF - 2020-2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>36a23c7c-8b4e-42b9-9530-ae9d22b97bb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf</value>
      <webElementGuid>61e428e5-1375-49d5-9d70-ea38fb58b498</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>NIRF - 2020-2021</value>
      <webElementGuid>baba0d9b-4731-4be5-8940-e46f8d675986</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NIRF - 2020-2021</value>
      <webElementGuid>7130a550-490c-4f68-8612-439fe987ac5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[3]/a[1]</value>
      <webElementGuid>cfac3618-6f69-4c9a-b57e-dc58f803c53b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      <webElementGuid>0ac24581-3ee4-4704-b8f4-5f266f4cbdb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NIRF - 2020-2021')]</value>
      <webElementGuid>13018ae6-dad6-4645-8773-a1116a0008cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2021-2022'])[1]/following::a[1]</value>
      <webElementGuid>382d1963-1612-4cd3-933a-4679f6e060dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2022-2023'])[1]/following::a[2]</value>
      <webElementGuid>4cd5388b-c544-425e-aa38-7bf0487d1ea1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2018-2019'])[1]/preceding::a[1]</value>
      <webElementGuid>3de42504-698a-4c19-8a59-f96f84fa650d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>4df4c8fb-3f9e-4aff-a298-a75f30e4edf6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NIRF - 2020-2021']/parent::*</value>
      <webElementGuid>2e760195-803e-46bc-83a0-373d2d7e91eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf')]</value>
      <webElementGuid>326359cf-8323-434a-8469-8cd4502ac650</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/a</value>
      <webElementGuid>5ba90300-3241-4273-977b-1c3b9f6acd1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf' and @title = 'NIRF - 2020-2021' and (text() = 'NIRF - 2020-2021' or . = 'NIRF - 2020-2021')]</value>
      <webElementGuid>99b005db-b5eb-43df-8700-1a3dec68c85e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
