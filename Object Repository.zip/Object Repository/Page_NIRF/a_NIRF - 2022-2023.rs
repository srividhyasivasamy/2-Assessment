<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NIRF - 2022-2023</name>
   <tag></tag>
   <elementGuidId>8e6c500a-9810-4409-b3a7-bf5683230012</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;NIRF - 2022-2023&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NIRF - 2022-2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>63bc0f32-2236-4805-bdeb-01355cee3428</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2022-2023.pdf</value>
      <webElementGuid>c1143178-3231-4709-8f4e-42d0aead709a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>NIRF - 2022-2023</value>
      <webElementGuid>6f6675be-0299-4003-93cd-53e2b948e96b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NIRF - 2022-2023</value>
      <webElementGuid>6a0b34f4-3e93-482a-8bb8-d432711f3e8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[1]/a[1]</value>
      <webElementGuid>13a9749a-f3d6-4909-ae14-0be3327f7e34</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/a</value>
      <webElementGuid>954804eb-e57e-487d-9fde-ec434c261e4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NIRF - 2022-2023')]</value>
      <webElementGuid>7815bdf6-294b-4c42-ac76-41b54214bc2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[3]/following::a[1]</value>
      <webElementGuid>2c41dd4f-cf24-4327-8686-f3bd2a79087b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[3]</value>
      <webElementGuid>d41ddd9c-5850-4cbd-8da8-7684f51c499d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2021-2022'])[1]/preceding::a[1]</value>
      <webElementGuid>5a4be086-7ef6-4d5f-be7a-8e77ac0a837e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2020-2021'])[1]/preceding::a[2]</value>
      <webElementGuid>2e75b030-dffe-4dd4-89f3-cf4c6463ac09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NIRF - 2022-2023']/parent::*</value>
      <webElementGuid>fc3b0384-ca86-4386-897f-9fe8a1eee1d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2022-2023.pdf')]</value>
      <webElementGuid>ad3deeef-c378-4eaf-9e06-b9cea9ad2608</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>b918cb34-6d66-49c1-bae7-4ab281c0dc30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2022-2023.pdf' and @title = 'NIRF - 2022-2023' and (text() = 'NIRF - 2022-2023' or . = 'NIRF - 2022-2023')]</value>
      <webElementGuid>a0c4021d-77d6-4e5c-878b-8664e5e472c1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
