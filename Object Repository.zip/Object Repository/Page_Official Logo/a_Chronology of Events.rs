<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Chronology of Events</name>
   <tag></tag>
   <elementGuidId>829c7dbf-e6e6-4e43-a778-b1541a562288</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[2]/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Chronology of Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f6f004bd-4337-408f-b035-7f1a75be6f3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chronology-of-events</value>
      <webElementGuid>975cdf1d-e49d-462e-9c77-4096cc8d453e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chronology of Events</value>
      <webElementGuid>8cd499b3-6b55-4907-92d5-90a4ef4c4367</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>4e1137ed-ce1b-4dfe-bc82-a04b4bf04836</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[2]/ul/li[3]/a</value>
      <webElementGuid>374185e6-245c-4c76-a593-3e3949020b1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Chronology of Events')]</value>
      <webElementGuid>06be4179-707b-45e3-896e-892336cf903c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision and Mission'])[1]/following::a[1]</value>
      <webElementGuid>250eca19-7594-41c0-8c1b-be4cede0d34d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile of the College'])[1]/preceding::a[1]</value>
      <webElementGuid>0c167188-d523-4a3d-934b-15e556de3d9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Official Logo'])[2]/preceding::a[2]</value>
      <webElementGuid>8b853676-af26-4869-8f6e-ee923d65f9f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chronology of Events']/parent::*</value>
      <webElementGuid>89801e49-db6c-4be0-9e33-59e3e675e9b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chronology-of-events')]</value>
      <webElementGuid>e93c909d-d53c-4f57-838a-4db856a5998e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[3]/a</value>
      <webElementGuid>b2857f35-2fbd-4e14-9049-69cb017fac0a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chronology-of-events' and (text() = 'Chronology of Events' or . = 'Chronology of Events')]</value>
      <webElementGuid>b3cb5394-5727-487d-a0e6-814738f0563f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
