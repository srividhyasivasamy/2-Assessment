<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_FDP  PDP</name>
   <tag></tag>
   <elementGuidId>0741de87-f0f5-4a52-bc40-c8fd7c6cbc4a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[14]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(14) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;FDP / PDP&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>86a13b2f-95f0-4bc1-bee0-bc0eb8019a07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/fdppdp</value>
      <webElementGuid>7bc1502b-aef3-45de-b3b4-02e51f5d9847</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>FDP / PDP</value>
      <webElementGuid>c2bd47c8-bea5-4fe2-8649-89010820c30f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[14]/a[1]</value>
      <webElementGuid>a511f6ce-66e0-4a68-8454-7d6b2b760455</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[14]/a</value>
      <webElementGuid>3ee7f59c-8df5-40a6-bcd1-f6fc639fa1a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'FDP / PDP')]</value>
      <webElementGuid>69df8b67-b3f3-4b0d-b3b0-fa197147e929</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Orientation / FIP'])[1]/following::a[1]</value>
      <webElementGuid>7ef0fd62-f7e0-4c12-b447-1dbd10e4a6bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[1]/following::a[2]</value>
      <webElementGuid>ba375f2d-2218-4ef1-9fe2-f51a61c9d6c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Autonomy'])[1]/preceding::a[1]</value>
      <webElementGuid>ce7e4e14-7936-4d4e-b70b-512e0803659f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Statutory Bodies'])[1]/preceding::a[2]</value>
      <webElementGuid>7260fd38-a776-4bed-a69b-22a6f22bcd0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='FDP / PDP']/parent::*</value>
      <webElementGuid>4a9c42f7-da2d-4c10-b9d8-25e3ece8a23c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/fdppdp')]</value>
      <webElementGuid>49588cbc-d533-4dd3-ac59-065069bb06aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[14]/a</value>
      <webElementGuid>91ce1be9-44d8-4bcd-bd89-88c55f3a896a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/fdppdp' and (text() = 'FDP / PDP' or . = 'FDP / PDP')]</value>
      <webElementGuid>e379cd8a-d0a5-42c5-9301-163c720e2519</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
