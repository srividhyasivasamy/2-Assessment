<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NSCAS Newsletter</name>
   <tag></tag>
   <elementGuidId>c9aecda6-ff71-4eaf-b4f2-84f18ce22d5d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NSCAS Newsletter&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6b28e696-4a5f-4d77-9150-98385803e1d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>9f175e89-f64c-489a-84e0-6b7386624869</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NSCAS Newsletter</value>
      <webElementGuid>d0b5db8c-b40a-4d70-b9ae-aed74f7330b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;bg-light footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;border-0 shadow card&quot;]/div[@class=&quot;card-body&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>ab9204ab-cedd-44a8-b937-f2e5d43608ae</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[3]/div/div[2]/ul/li/a</value>
      <webElementGuid>0ea04624-f052-44fd-b57f-0e3924c7fc4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NSCAS Newsletter')]</value>
      <webElementGuid>760866ea-ba2f-43e9-bb11-2e1798f73cd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/following::a[1]</value>
      <webElementGuid>4f136cc4-8610-4c57-9699-dbe60a2c85b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/following::a[1]</value>
      <webElementGuid>0a9c95a1-60dc-44d2-85d9-3f08f7134782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NPTEL'])[1]/preceding::a[1]</value>
      <webElementGuid>50546fa2-910a-475c-a016-66ca4092acf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Grievances'])[1]/preceding::a[2]</value>
      <webElementGuid>d6e8a16e-41aa-4baf-b510-6fe77fa9bad1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NSCAS Newsletter']/parent::*</value>
      <webElementGuid>30ec46b9-b805-4bb0-afe8-ffa3c3ceaa90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '')])[108]</value>
      <webElementGuid>344ed1a3-06c9-4ee2-a1b1-676c63c0fb2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]/ul/li/a</value>
      <webElementGuid>ffbfd5db-f21a-4a61-b476-49ab7cbb54d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'NSCAS Newsletter' or . = 'NSCAS Newsletter')]</value>
      <webElementGuid>16d8fafe-964e-48c2-b55d-c751df9b285b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
