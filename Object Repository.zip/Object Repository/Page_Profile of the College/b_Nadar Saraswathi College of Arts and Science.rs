<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_Nadar Saraswathi College of Arts and Science</name>
   <tag></tag>
   <elementGuidId>3757ed68-3283-4a91-a635-9e1b48c6da97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr/td[2]/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Nadar Saraswathi College of Arts and Science&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>df5429b8-523f-409f-9e6e-af93b41d3c9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 Nadar Saraswathi College of Arts and Science
 </value>
      <webElementGuid>a4737c11-83b5-4e08-b34f-499f0d4a887c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;table table-bordered table-striped&quot;]/tbody[1]/tr[1]/td[2]/b[1]</value>
      <webElementGuid>2db8ba7e-4013-446b-bfbd-daca7a0a2462</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr/td[2]/b</value>
      <webElementGuid>a8f7c3b5-96dc-4d93-9772-c836243986c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name of the College'])[1]/following::b[1]</value>
      <webElementGuid>45f03d94-ce9f-4b4c-ad3d-4d33e005958b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROFILE OF THE COLLEGE'])[1]/following::b[1]</value>
      <webElementGuid>820e5ced-d38b-4ad7-bbaf-43866bc6ee76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Place'])[1]/preceding::b[1]</value>
      <webElementGuid>7caeff47-9771-47ba-917a-eb87d9e43779</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nadar Saraswathi College of Arts and Science']/parent::*</value>
      <webElementGuid>e284f4b1-3569-4361-aacc-e9ac2ac40b4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//b</value>
      <webElementGuid>8e5eb46f-c73b-40b8-9060-99c5cf59169f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = '
 Nadar Saraswathi College of Arts and Science
 ' or . = '
 Nadar Saraswathi College of Arts and Science
 ')]</value>
      <webElementGuid>fdd2f10d-3349-4d88-9afc-df3fad14439c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
