<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click here_1</name>
   <tag></tag>
   <elementGuidId>e09cc8f8-d03c-4bbc-9995-3eb73413507a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[2]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(2) > td:nth-of-type(2) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;IQAC-NSCAS-Newsletter-Volume 13, Issue 2 (Bi-annual), December, 2022 Click here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>fb49c0f8-bfdd-497e-99dc-174f4b193b25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2022.pdf</value>
      <webElementGuid>831054a9-7f55-4246-9c51-53f820ee5557</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>f2ba2cde-84ad-44cc-a2e3-97f1c472f409</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>284cfadf-eb81-41d5-9996-1e39e26d34be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here</value>
      <webElementGuid>8df24fc1-680f-4aef-a711-c6ea4df98da0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;table table-bordered table-hover table-striped&quot;]/tbody[1]/tr[2]/td[2]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>eaaaa695-1808-4e8b-b9d0-fec0bc1056b6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[2]/td[2]/a</value>
      <webElementGuid>41fa6443-c674-4aae-8879-b6c73f10ed44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click here')])[2]</value>
      <webElementGuid>b5f951cc-6fdc-4270-afd1-3e2130a4bd84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-NSCAS-Newsletter-Volume 13, Issue 2 (Bi-annual), December, 2022'])[1]/following::a[1]</value>
      <webElementGuid>23ec3a9c-21a5-4a3c-ae7a-a26aba059f1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[1]/following::a[1]</value>
      <webElementGuid>1c7c90df-56e6-4080-b87a-14971fc7be30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-NSCAS-Newslettr-Volume 13, Issue 1 (Bi-annual), June, 2022'])[1]/preceding::a[1]</value>
      <webElementGuid>45d5ebec-841d-4649-9dd7-e844243322c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[3]/preceding::a[1]</value>
      <webElementGuid>0cd95da1-87a5-49b5-a4e5-979a554fd06f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2022.pdf')]</value>
      <webElementGuid>9ef5100a-29fd-4ab2-a4b3-015d731149db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]/a</value>
      <webElementGuid>0d1f34f8-674d-4f69-9ecb-e2233d7226d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2022.pdf' and (text() = 'Click here' or . = 'Click here')]</value>
      <webElementGuid>9e08b7e6-f8eb-4355-b084-1acede59a2ec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
