<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click here_1_2</name>
   <tag></tag>
   <elementGuidId>809e5d85-3e0e-472d-aaca-ecddb1db0941</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[3]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(3) > td:nth-of-type(2) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;IQAC-NSCAS-Newslettr-Volume 13, Issue 1 (Bi-annual), June, 2022 Click here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a8c81de9-876e-4a3b-82fe-f559c638177a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterJune2022.pdf</value>
      <webElementGuid>4eff6ef7-8edb-4597-9e84-fb2647046bdc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>a69f5429-8fc8-4961-beef-0e5c81c9f5e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>73d28bce-5520-439a-af3f-b7fc4664e6e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here</value>
      <webElementGuid>1d06b5da-6c5d-4351-8beb-255baaa65857</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;table table-bordered table-hover table-striped&quot;]/tbody[1]/tr[3]/td[2]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>cf09a016-5cf5-49e2-b7a4-0898d0895afa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[3]/td[2]/a</value>
      <webElementGuid>8a9c8978-8fcf-473e-945d-6824279b75c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click here')])[3]</value>
      <webElementGuid>56c53066-7157-41e2-be4c-786369d6e732</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-NSCAS-Newslettr-Volume 13, Issue 1 (Bi-annual), June, 2022'])[1]/following::a[1]</value>
      <webElementGuid>e6d21aff-3831-49d3-a9b8-1b12fc8dbad3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[2]/following::a[1]</value>
      <webElementGuid>4e2f3813-1002-4fa6-bb16-c0ce081a47f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-NSCAS-Newsletter-Volume 12, Issue 2 (Bi-annual) December, December, 2021'])[1]/preceding::a[1]</value>
      <webElementGuid>dfc26949-2d56-4ab5-92b4-a3bbf78211d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click Here'])[1]/preceding::a[1]</value>
      <webElementGuid>69226544-f631-40b3-92ac-843efca4278f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterJune2022.pdf')]</value>
      <webElementGuid>9dd1b510-e417-43fc-a37c-618437c96bfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]/a</value>
      <webElementGuid>abda8bd4-9068-4efe-9dc0-823ee2102ac8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterJune2022.pdf' and (text() = 'Click here' or . = 'Click here')]</value>
      <webElementGuid>04607712-08ec-4aeb-a3f3-f22ab5493a4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
