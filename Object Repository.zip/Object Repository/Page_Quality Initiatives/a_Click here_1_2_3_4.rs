<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click here_1_2_3_4</name>
   <tag></tag>
   <elementGuidId>4c2d6189-dc6c-4bff-9fd2-e7466d18e598</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[8]/td[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(8) > td:nth-of-type(2) > a.btn.btn-primary.btn-sm</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;IQAC-NSCAS-Newsletter-Volume 10, Issue 2 (Bi-annual), December, 2019 Click here&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f60fb131-3a8d-447a-8996-2e547548231e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2019.pdf</value>
      <webElementGuid>be8da4bf-fdd6-47f5-ace5-f426780197b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary btn-sm</value>
      <webElementGuid>9eafef36-def0-4591-b5f8-e52a8f58b09f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>7da8fad6-092e-4eb6-b73a-f8f026ef7836</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here</value>
      <webElementGuid>877880d0-f1ac-4e91-b331-acc3e2f8d456</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;table table-bordered table-hover table-striped&quot;]/tbody[1]/tr[8]/td[2]/a[@class=&quot;btn btn-primary btn-sm&quot;]</value>
      <webElementGuid>1dd64d6a-9c29-47dd-9f6b-dd4447df359f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[8]/td[2]/a</value>
      <webElementGuid>0a9a5856-5796-4bd1-88fe-a63453498193</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Click here')])[5]</value>
      <webElementGuid>9e2d98f4-5fd4-4148-8457-c0cbae9355b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[4]/following::a[1]</value>
      <webElementGuid>82a8a0e8-4dff-4ded-8459-7888537ba33a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-NSCAS-Newsletter-Volume 10, Issue 1 (Bi-annual), June, 2019'])[1]/preceding::a[1]</value>
      <webElementGuid>cf5138f7-3341-4e6c-915d-a3156d181eb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here'])[6]/preceding::a[1]</value>
      <webElementGuid>c9880bee-c248-456d-8766-ebff5bbd7588</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2019.pdf')]</value>
      <webElementGuid>dd64a634-99f9-4337-a0ef-bceabf773372</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[8]/td[2]/a</value>
      <webElementGuid>7ca10d99-b769-4bcd-ba7c-a9ff22603f40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/Newsletter/IQACNewsletterDecember2019.pdf' and (text() = 'Click here' or . = 'Click here')]</value>
      <webElementGuid>95edff07-ae54-4418-afe8-b575c5c07a52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
