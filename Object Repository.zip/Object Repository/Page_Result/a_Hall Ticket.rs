<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Hall Ticket</name>
   <tag></tag>
   <elementGuidId>0c755c9c-0a16-424a-ad8d-936ad451c5a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[6]/ul/li[2]/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Hall Ticket&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>59f82ac8-3c45-4962-9ea4-a8aadadb34d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/hall-ticket</value>
      <webElementGuid>cd62f8d5-e428-4b1a-8313-0afdf7ba1c7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hall Ticket</value>
      <webElementGuid>14a66e7e-975b-4dd4-802a-471c65a6c4a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>9a3eb258-b30a-4ffe-b9e4-b5ffff3c47f8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[6]/ul/li[2]/ul/li/a</value>
      <webElementGuid>59a81660-79cc-4736-95bd-0c4b8692e0f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Hall Ticket')]</value>
      <webElementGuid>ebeaaf6e-2abd-4293-984d-2929bee390d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examinations - Exam'])[1]/following::a[1]</value>
      <webElementGuid>53833bee-5c0e-428e-9ed1-d74612c55226</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Office of CoE'])[1]/following::a[2]</value>
      <webElementGuid>e391c61e-f9e2-4e26-bd6b-08561ccd7edf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Result'])[2]/preceding::a[1]</value>
      <webElementGuid>013f1b2e-e58a-4f5a-89a8-e546931ff81e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CIA'])[1]/preceding::a[2]</value>
      <webElementGuid>6fc27c19-f5f8-465b-8f6e-8ef47b834f09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hall Ticket']/parent::*</value>
      <webElementGuid>dc927c94-05d1-4647-bbd3-640745a3183e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/hall-ticket')]</value>
      <webElementGuid>e0bb9785-af08-416a-8586-d484992d1b96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/ul/li[2]/ul/li/a</value>
      <webElementGuid>39a1a3bc-f3f0-4cc1-bab4-d03a4f081448</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/hall-ticket' and (text() = 'Hall Ticket' or . = 'Hall Ticket')]</value>
      <webElementGuid>a38893a1-34b8-43da-9c1e-dba4789c839b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
