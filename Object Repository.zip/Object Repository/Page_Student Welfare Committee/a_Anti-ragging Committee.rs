<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Anti-ragging Committee</name>
   <tag></tag>
   <elementGuidId>d8840da2-0066-4737-85f2-c4bdf905bc26</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Anti-ragging Committee&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>655d7157-578d-4659-b037-f66d275f0ddd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/antiragging-committee</value>
      <webElementGuid>138e466d-26ec-466b-aebf-5f2de2001cde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Anti-ragging Committee</value>
      <webElementGuid>57ccb357-34d2-40c4-9f2e-45fe03b660be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[2]/a[1]</value>
      <webElementGuid>6bdddef2-0459-44b1-963a-5d6efde7b05d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>6a3fcf25-6ca4-4725-8dc2-89fe31ee534b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Anti-ragging Committee')]</value>
      <webElementGuid>22c7536f-ac1a-44a8-98bc-8120ffe421e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ICC'])[1]/following::a[1]</value>
      <webElementGuid>a64ead19-75ec-426c-b370-c40c21233e70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Non-Statutory Bodies'])[1]/following::a[2]</value>
      <webElementGuid>8bf9cc27-0b75-47f3-8b43-fc4f72f7da3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Welfare Committee'])[2]/preceding::a[1]</value>
      <webElementGuid>52a71243-7ad9-42f9-98c9-4a55885e7347</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Women Harassment, Grievance Redressal &amp; Ombudsman'])[1]/preceding::a[2]</value>
      <webElementGuid>9817491b-b7c6-4048-a1f1-c294c66ccd93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Anti-ragging Committee']/parent::*</value>
      <webElementGuid>8a872a61-0653-4f07-b081-76b847b91f7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/antiragging-committee')]</value>
      <webElementGuid>47c5694a-dd9d-4265-aa0d-c44e4ce5eed9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li[2]/ul/li[2]/a</value>
      <webElementGuid>76df050d-d151-436d-afc6-aa913588b85c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/antiragging-committee' and (text() = 'Anti-ragging Committee' or . = 'Anti-ragging Committee')]</value>
      <webElementGuid>0e21226b-b280-404c-96c2-03884869f37f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
