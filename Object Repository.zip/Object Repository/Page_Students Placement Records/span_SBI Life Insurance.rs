<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SBI Life Insurance</name>
   <tag></tag>
   <elementGuidId>03ccabf7-75da-4edc-879f-f149c469f792</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[6]/td[2]/p/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(6) > td:nth-of-type(2) > p.MsoNormal > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;SBI Life Insurance&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fba0d5ab-a28f-4528-b1af-47e4565f36b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>EN-US</value>
      <webElementGuid>f83b54cf-d6b7-45c8-b640-4ec46ee8e70d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SBI Life
 Insurance</value>
      <webElementGuid>ff202635-32a8-4c29-9b7c-c766af6d7f51</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[@class=&quot;MsoTableGrid&quot;]/tbody[1]/tr[6]/td[2]/p[@class=&quot;MsoNormal&quot;]/span[1]</value>
      <webElementGuid>f8cf416e-deb6-49d4-98bf-00e5c2305fb6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[6]/td[2]/p/span</value>
      <webElementGuid>d4523a7c-2511-4be9-b6c3-b062039ffbf3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Wipro WILP'])[1]/following::span[6]</value>
      <webElementGuid>eaf41774-e7b0-4e17-bcd0-c2f82b5a26fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[6]/td[2]/p/span</value>
      <webElementGuid>a89adc1f-4779-4b4a-a1d1-43d3c4190cc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SBI Life
 Insurance' or . = 'SBI Life
 Insurance')]</value>
      <webElementGuid>38511b1e-79f1-41a6-8b43-90ecb5bd60f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
