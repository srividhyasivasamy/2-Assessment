<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_PG Syllabus - From 2021</name>
   <tag></tag>
   <elementGuidId>38c8789f-8f8a-47af-911a-945456b106fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(5) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;PG Syllabus - From 2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>87c133b8-2065-410c-9756-0b7522b4c0d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://old.motherteresawomenuniv.ac.in/pg%20syll%20year%20new.html</value>
      <webElementGuid>0609042c-8c98-4c08-aa27-b5e0e799a91c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>64051a85-950e-4dc9-9e79-44e32bf6a390</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PG Syllabus - From 2021</value>
      <webElementGuid>ab946f3a-a6a0-4a73-b0dc-b839c624e29c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[5]/a[1]</value>
      <webElementGuid>51ba5e90-7460-4cd2-8dba-cf6fd0046655</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      <webElementGuid>47e404b7-6edc-41f3-87b3-e8f584459d8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'PG Syllabus - From 2021')]</value>
      <webElementGuid>e94adb57-d88a-4966-83af-d9415795bf9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG Syllabus - From 2021'])[1]/following::a[1]</value>
      <webElementGuid>e97a3b29-091c-431e-991f-6d444370f2f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Affiliated to MTWU, Kodaikanal'])[1]/following::a[2]</value>
      <webElementGuid>09c3a8e6-d2af-4be9-8760-5c077e1ca6d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised TANSCHE Syllabus for UG and PG from 2023 onwards'])[1]/preceding::a[1]</value>
      <webElementGuid>69714666-5e20-4df4-acfe-5d05257cfbc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>fe20a097-54bf-4ce3-bab2-990295049405</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PG Syllabus - From 2021']/parent::*</value>
      <webElementGuid>2de9ecef-380d-4f11-b80d-f75edafcb935</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://old.motherteresawomenuniv.ac.in/pg%20syll%20year%20new.html')]</value>
      <webElementGuid>9e419fa8-b812-4e37-b726-de9e31ce2e83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/a</value>
      <webElementGuid>f412b50c-3bf6-4ec1-82ec-1ec8a4d7b99a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://old.motherteresawomenuniv.ac.in/pg%20syll%20year%20new.html' and (text() = 'PG Syllabus - From 2021' or . = 'PG Syllabus - From 2021')]</value>
      <webElementGuid>ba53fa5f-c3f6-4683-9a9a-042f97f5979d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
