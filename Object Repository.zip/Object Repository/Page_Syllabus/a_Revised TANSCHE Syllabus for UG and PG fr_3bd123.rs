<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Revised TANSCHE Syllabus for UG and PG fr_3bd123</name>
   <tag></tag>
   <elementGuidId>69ac98a5-b880-452b-ba52-2f0c0e3c4e94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[7]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(7) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Revised TANSCHE Syllabus for UG and PG from 2023 onwards&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>18d3c9a8-25e2-4a05-a506-310f723a567b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://old.motherteresawomenuniv.ac.in/revised%20tansche%20syll%202023.html</value>
      <webElementGuid>0a3dc5ab-03d1-4fef-8c8e-f993a0e7114d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>aa242a63-fd6f-4be1-aa0f-c26629bcc402</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Revised TANSCHE Syllabus for UG and PG from 2023 onwards</value>
      <webElementGuid>ee9da864-321f-4486-b1ae-ff6acf358792</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[7]/a[1]</value>
      <webElementGuid>93ecc7e6-d6f8-4f35-b541-680df5d0790c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[7]/a</value>
      <webElementGuid>6e0e2451-7928-4af5-90af-d41309572918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Revised TANSCHE Syllabus for UG and PG from 2023 onwards')]</value>
      <webElementGuid>8d3e1b7a-559a-4d63-9c64-5d571c21ae7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG Syllabus - From 2021'])[1]/following::a[1]</value>
      <webElementGuid>fb9cdea5-102f-4954-a836-0f8c272be1ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG Syllabus - From 2021'])[1]/following::a[2]</value>
      <webElementGuid>62e4b412-70c5-4790-9f97-4efaf97e2460</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>ab1ed4e2-a7e5-4290-93ba-a6ea4bf07204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>ef951e03-36ae-4746-acf2-687720a13151</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Revised TANSCHE Syllabus for UG and PG from 2023 onwards']/parent::*</value>
      <webElementGuid>26c87214-b758-419e-8413-f4229d10c1a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://old.motherteresawomenuniv.ac.in/revised%20tansche%20syll%202023.html')]</value>
      <webElementGuid>028b2f8b-4ff9-4a45-a166-d7989f7e3624</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[7]/a</value>
      <webElementGuid>9a2ac5b7-3aca-4706-a074-a77feaddad7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://old.motherteresawomenuniv.ac.in/revised%20tansche%20syll%202023.html' and (text() = 'Revised TANSCHE Syllabus for UG and PG from 2023 onwards' or . = 'Revised TANSCHE Syllabus for UG and PG from 2023 onwards')]</value>
      <webElementGuid>2c7ea8da-c7d6-4f62-a603-46d534c05733</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
