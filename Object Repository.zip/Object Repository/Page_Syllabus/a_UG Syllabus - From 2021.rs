<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_UG Syllabus - From 2021</name>
   <tag></tag>
   <elementGuidId>9d85a7da-b283-462d-bcd7-dd43ccb423f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;UG Syllabus - From 2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a6101260-1efa-4904-b7ed-09d51b1b4e9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://old.motherteresawomenuniv.ac.in/ug%20syll%20year%20new.html</value>
      <webElementGuid>e0d66843-b5d1-4405-a056-977e26541ee2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>94a6578d-7dcf-4696-804c-0891d3d3124e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG Syllabus - From 2021</value>
      <webElementGuid>a47aced2-9b9c-4619-b102-95dbdb9f6a81</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[3]/a[1]</value>
      <webElementGuid>e9d3ebf1-22e6-47e2-a02d-a3631c2fbb19</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      <webElementGuid>d6a7d872-4b6e-47a8-9600-ca4f56b54c03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'UG Syllabus - From 2021')]</value>
      <webElementGuid>6083cca7-a7e6-4ea9-bddb-6b7bc75881c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Affiliated to MTWU, Kodaikanal'])[1]/following::a[1]</value>
      <webElementGuid>40503eda-596e-44c9-8faa-da409cddad4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SYLLABUS'])[1]/following::a[1]</value>
      <webElementGuid>8f57f5dc-9092-44ef-85db-6121fcd5c69b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG Syllabus - From 2021'])[1]/preceding::a[1]</value>
      <webElementGuid>e98d2fef-e146-4160-be50-7a631612cac6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revised TANSCHE Syllabus for UG and PG from 2023 onwards'])[1]/preceding::a[2]</value>
      <webElementGuid>6ae54f5f-3f1b-4d71-8633-a307ee6a3faa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG Syllabus - From 2021']/parent::*</value>
      <webElementGuid>7db3b4a8-28a2-4d4b-bbc6-0a715e2d21b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://old.motherteresawomenuniv.ac.in/ug%20syll%20year%20new.html')]</value>
      <webElementGuid>8b3a7e00-f0bd-4849-8a53-d50616cd6fc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/a</value>
      <webElementGuid>16f4025d-a7fa-4b80-b494-572ebef26c0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://old.motherteresawomenuniv.ac.in/ug%20syll%20year%20new.html' and (text() = 'UG Syllabus - From 2021' or . = 'UG Syllabus - From 2021')]</value>
      <webElementGuid>d28da585-9b60-4df5-a5a0-228f2a12f847</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
