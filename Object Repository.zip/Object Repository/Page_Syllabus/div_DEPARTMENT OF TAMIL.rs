<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_DEPARTMENT OF TAMIL</name>
   <tag></tag>
   <elementGuidId>0bee65d9-2cbc-41d6-9220-509c9b020284</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.d-flex.justify-content-center.align-items-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;DEPARTMENT OF TAMIL&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c397ac9b-e911-487d-94c8-f6b60a8fbe0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-flex justify-content-center align-items-center</value>
      <webElementGuid>5029f53a-ec51-48f6-be2d-44c763422771</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>DEPARTMENT OF TAMIL</value>
      <webElementGuid>57883290-8ee3-44a2-a18b-1cfcfc35dad5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;mb-4 col-md-4&quot;]/a[1]/div[@class=&quot;home-top-cour py-0&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;fw-bold text-dark col-md-8 col-8&quot;]/div[@class=&quot;d-flex justify-content-center align-items-center&quot;]</value>
      <webElementGuid>764002a9-ae08-419c-90c4-db4aea6e1de4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      <webElementGuid>6efd46d4-fdc1-4ddc-ba8f-9e9893ca5e3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[2]/following::div[9]</value>
      <webElementGuid>ffce0b14-fd73-4493-84e4-4f9e73ec6c15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[17]</value>
      <webElementGuid>8a91a5b1-d7f7-44f1-a805-c389fc0f66d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='DEPARTMENT OF']/parent::*</value>
      <webElementGuid>7b603628-7a91-4c0c-8e87-5b82e8cf277f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div/div[2]/div</value>
      <webElementGuid>0b81b014-6dba-4bd0-b0e7-405ea0e9c5b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'DEPARTMENT OF TAMIL' or . = 'DEPARTMENT OF TAMIL')]</value>
      <webElementGuid>f24ebd42-f2fb-4c78-9831-70b0b9a577e7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
