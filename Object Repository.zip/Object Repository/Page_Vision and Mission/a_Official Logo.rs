<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Official Logo</name>
   <tag></tag>
   <elementGuidId>afd3fdf3-1a5a-47ea-8267-25d656a94246</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[2]/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li:nth-of-type(5) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Official Logo&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>580daab1-2c5c-4bc9-8a9d-eb88905796cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/official-logo</value>
      <webElementGuid>f7bfe605-4584-44d9-ae88-da5f9e4a9905</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Official Logo</value>
      <webElementGuid>77f043b2-4fd8-4421-a78c-928f7f9bebaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[5]/a[1]</value>
      <webElementGuid>c836dde4-0323-4b9e-b497-f36ad9b800cd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[2]/ul/li[5]/a</value>
      <webElementGuid>0e90977a-ca3a-4e95-97a7-7624863c9c93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Official Logo')]</value>
      <webElementGuid>b5989d79-87be-4d40-82c9-5176cb81e329</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile of the College'])[1]/following::a[1]</value>
      <webElementGuid>63be981c-f910-4071-bc9c-9b99e2bc6620</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chronology of Events'])[1]/following::a[2]</value>
      <webElementGuid>ab1b87b7-4b05-4af0-bb6e-12dfbf6eec6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::a[1]</value>
      <webElementGuid>9a6ee5fe-a22c-40a3-a187-8eddfdaf8cc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Organogram'])[1]/preceding::a[2]</value>
      <webElementGuid>405749a1-e1fd-4ed4-830c-c46f02a47305</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Official Logo']/parent::*</value>
      <webElementGuid>5edcd577-5b43-4728-ad92-1e63b96b7a97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/official-logo')]</value>
      <webElementGuid>07a5f5e4-13e2-4c87-8b79-30901645f4fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[5]/a</value>
      <webElementGuid>ec568caf-414f-4d67-962b-7c6c0a0c7706</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/official-logo' and (text() = 'Official Logo' or . = 'Official Logo')]</value>
      <webElementGuid>72f9cd97-d69e-42c4-b8b4-b89861b0f484</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
