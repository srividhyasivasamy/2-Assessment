<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Internal Committee for Disability Students</name>
   <tag></tag>
   <elementGuidId>e51d2bf7-8d5b-4cb8-a41b-196fb7df225b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Internal Committee for Disability Students&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2e59eb30-8c71-4314-8534-dff404781da3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/internal-committee-for-disability-students</value>
      <webElementGuid>46734c8a-10bc-4a37-9717-bf752d29598a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Internal Committee for Disability Students</value>
      <webElementGuid>d4e612e9-738d-49d2-905f-a068a3cb0b9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[5]/a[1]</value>
      <webElementGuid>3165d07c-f67e-4514-9519-8c2802889ba9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[8]/ul/li[2]/ul/li[5]/a</value>
      <webElementGuid>71279543-1264-4a6b-8d97-8611dd460e6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Internal Committee for Disability Students')]</value>
      <webElementGuid>9c7f459b-7f06-4414-89b1-16d4979a95a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Women Harassment, Grievance Redressal &amp; Ombudsman'])[2]/following::a[1]</value>
      <webElementGuid>74d9ed4d-a05a-4bd8-b54f-b60c80e34dab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Welfare Committee'])[1]/following::a[2]</value>
      <webElementGuid>d2d17758-d10f-4d89-be58-935c791aa2c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDC cum Earn while you Learn'])[1]/preceding::a[1]</value>
      <webElementGuid>2874adb3-b5e0-466e-abd0-3ab328a7c0ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clubs'])[1]/preceding::a[2]</value>
      <webElementGuid>5dc66909-2234-4d51-ae5b-0c16dbb09350</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Internal Committee for Disability Students']/parent::*</value>
      <webElementGuid>050e83ad-2bd8-492e-8d07-4a3fe991685d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/internal-committee-for-disability-students')]</value>
      <webElementGuid>091a3158-0ffc-4d31-bfd9-fc5471733e0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/ul/li[2]/ul/li[5]/a</value>
      <webElementGuid>aec1bc73-61c3-401a-8218-d5c19e3c988f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/internal-committee-for-disability-students' and (text() = 'Internal Committee for Disability Students' or . = 'Internal Committee for Disability Students')]</value>
      <webElementGuid>9184b1af-de1d-4e09-96fa-3ddcf1ccfef9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
